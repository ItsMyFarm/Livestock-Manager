// views.js — one function per screen. Each renders into #view-root and
// wires up its own event handlers. Kept framework-free on purpose.
const Views = (() => {
  const rootEl = () => document.getElementById('view-root');
  const setHtml = (html) => { rootEl().innerHTML = html; };

  const SHEEP_STATUSES = ['active', 'sold', 'deceased', 'archived'];
  const COW_STATUSES = ['milking', 'dry', 'rearing', 'sold', 'deceased', 'archived'];
  const SUCKLER_STATUSES = ['active', 'rearing', 'sold', 'deceased', 'archived'];

  // ---------- species helpers ----------
  // Three species share this codebase: 'sheep', 'cow' (dairy) and
  // 'sucklercow' (beef/suckler herd). Cow and sucklercow share almost all
  // behaviour (breeding & calving terminology, cattle sex labels, routing
  // under a herd rather than a flock) — the one thing that sets them apart
  // is milk recording, which only applies to dairy cows.
  const isCattle = (species) => species === 'cow' || species === 'sucklercow';
  const hasMilk = (species) => species === 'cow';
  const routeFor = (species) => species === 'cow' ? 'cows' : species === 'sucklercow' ? 'sucklers' : 'sheep';
  const speciesLabel = (species) => species === 'cow' ? 'Cow' : species === 'sucklercow' ? 'Suckler Cow' : 'Sheep';
  const speciesLabelLower = (species) => species === 'cow' ? 'cows' : species === 'sucklercow' ? 'suckler cows' : 'sheep';
  const herdLabel = (species) => species === 'cow' ? 'Dairy Herd' : species === 'sucklercow' ? 'Suckler Herd' : 'Flock';
  const speciesIcon = (species) => species === 'sheep' ? Icons.sheep : Icons.cow;
  const statusesFor = (species) => species === 'cow' ? COW_STATUSES : species === 'sucklercow' ? SUCKLER_STATUSES : SHEEP_STATUSES;
  const routeToSpecies = (route) => route === 'cows' ? 'cow' : route === 'sucklers' ? 'sucklercow' : 'sheep';

  const sexOptions = (species) => isCattle(species)
    ? [{ value: 'female', label: 'Female (Cow)' }, { value: 'male', label: 'Male (Bull)' }]
    : [{ value: 'female', label: 'Female (Ewe)' }, { value: 'male', label: 'Male (Ram)' }, { value: 'wether', label: 'Wether' }];

  function animalDisplay(a) { return a ? (a.name || a.tagNumber) : '—'; }

  async function withLoading(fn) {
    setHtml('<div class="empty-state">Loading…</div>');
    try { await fn(); } catch (e) {
      console.error(e);
      setHtml(`<div class="empty-state">Something went wrong: ${UI.esc(e.message)}</div>`);
      UI.toast(e.message, 'error');
    }
  }

  // ================= DASHBOARD =================
  async function dashboard() {
    await withLoading(async () => {
      const [dash, alerts, settings] = await Promise.all([Api.dashboard(), Api.alerts(), Api.getSettings()]);
      const modules = getModules(settings);
      const alertHtml = alerts.length
        ? alerts.slice(0, 8).map(a => `<div class="alert ${a.severity}">${UI.esc(a.message)}</div>`).join('')
        : UI.emptyState('No active alerts. All clear!');

      setHtml(`
        <div class="page-header">
          <div><h1>Dashboard</h1><p class="subtitle">Farm overview at a glance</p></div>
        </div>

        <div class="quick-add-bar">
          <button class="btn btn-primary" id="qa-treatment"><i class="ti ti-plus"></i> Treatment</button>
          <button class="btn" id="qa-bulk-treatment"><i class="ti ti-vaccine"></i> Bulk Treatment</button>
          <button class="btn btn-primary" id="qa-birth"><i class="ti ti-plus"></i> Birth / Lambing / Calving</button>
          ${modules.cows ? `<button class="btn btn-primary" id="qa-milk"><i class="ti ti-plus"></i> Milk Recording</button>` : ''}
          <button class="btn btn-primary" id="qa-weight"><i class="ti ti-plus"></i> Weight</button>
          <button class="btn btn-primary" id="qa-movement"><i class="ti ti-plus"></i> Movement</button>
          <button class="btn" id="qa-bulk-movement"><i class="ti ti-truck"></i> Batch Movement</button>
        </div>

        ${modules.sheep ? `
        <h2>${Icons.sheep} Sheep</h2>
        <div class="grid grid-4">
          ${UI.statCard('Total Sheep', dash.sheep.total)}
          ${UI.statCard('Ewes', dash.sheep.totalEwes)}
          ${UI.statCard('Lambs (under 6mo)', dash.sheep.totalLambs)}
          ${UI.statCard('Pregnant Ewes', dash.sheep.pregnantEwes)}
          ${UI.statCard('Lambings Due (21d)', dash.sheep.lambingsDueSoon.length, dash.sheep.lambingsDueSoon.length ? 'warn' : '')}
          ${UI.statCard('Under Withdrawal', dash.sheep.underWithdrawal, dash.sheep.underWithdrawal ? 'danger' : '')}
        </div>` : ''}

        ${modules.cows ? `
        <h2>${Icons.cow} Dairy Cows</h2>
        <div class="grid grid-4">
          ${UI.statCard('Total Cows', dash.cows.total)}
          ${UI.statCard('Milking', dash.cows.milking)}
          ${UI.statCard('Dry', dash.cows.dry)}
          ${UI.statCard('Rearing (Calves)', dash.cows.rearing)}
          ${UI.statCard('Calvings Due (21d)', dash.cows.calvingsDueSoon.length, dash.cows.calvingsDueSoon.length ? 'warn' : '')}
          ${UI.statCard('Under Withdrawal', dash.cows.underWithdrawal, dash.cows.underWithdrawal ? 'danger' : '')}
          ${UI.statCard("Today's Milk (L)", dash.cows.todaysMilk)}
        </div>` : ''}

        ${modules.sucklers ? `
        <h2>${Icons.cow} Suckler Cows</h2>
        <div class="grid grid-4">
          ${UI.statCard('Total Suckler Cows', dash.sucklers.total)}
          ${UI.statCard('Rearing (Calves)', dash.sucklers.rearing)}
          ${UI.statCard('Calvings Due (21d)', dash.sucklers.calvingsDueSoon.length, dash.sucklers.calvingsDueSoon.length ? 'warn' : '')}
          ${UI.statCard('Under Withdrawal', dash.sucklers.underWithdrawal, dash.sucklers.underWithdrawal ? 'danger' : '')}
        </div>` : ''}

        <div class="grid grid-2">
          <div class="card">
            <h3 style="margin-top:0"><i class="ti ti-alert-triangle"></i> Alerts</h3>
            ${alertHtml}
          </div>
          <div class="card">
            <h3 style="margin-top:0">Recent Activity</h3>
            <div class="tabs" style="border:none;margin-bottom:8px">
              <strong style="font-size:0.85rem;color:var(--text-dim)">Recent treatments</strong>
            </div>
            ${(modules.sheep ? dash.sheep.recentTreatments : []).concat(modules.cows ? dash.cows.recentTreatments : []).concat(modules.sucklers ? dash.sucklers.recentTreatments : [])
              .sort((a, b) => new Date(b.treatmentDate) - new Date(a.treatmentDate))
              .slice(0, 5)
              .map(t => `<div class="timeline-item" style="padding-bottom:8px"><span class="timeline-date">${UI.fmtDate(t.treatmentDate)}</span> — ${UI.esc(t.medicineName)}</div>`)
              .join('') || UI.emptyState('No treatments recorded yet.')}
          </div>
        </div>
      `);

      document.getElementById('qa-treatment').onclick = () => quickAddTreatment();
      document.getElementById('qa-bulk-treatment').onclick = () => { location.hash = '#/bulk-treatment'; };
      document.getElementById('qa-birth').onclick = () => quickAddBirth();
      if (modules.cows) document.getElementById('qa-milk').onclick = () => quickAddMilk();
      document.getElementById('qa-weight').onclick = () => quickAddWeight();
      document.getElementById('qa-movement').onclick = () => quickAddMovement();
      document.getElementById('qa-bulk-movement').onclick = () => { location.hash = '#/bulk-movement'; };
    });
  }

  async function animalPickerOptions(speciesFilter) {
    const animals = await Api.listAnimals(speciesFilter ? { species: speciesFilter } : {});
    return animals
      .filter(a => a.status !== 'archived')
      .map(a => ({ value: a.id, label: `${a.name || a.tagNumber} (${a.tagNumber}) — ${a.species}` }));
  }

  async function quickAddTreatment() {
    const options = await animalPickerOptions();
    if (!options.length) return UI.toast('Add an animal first.', 'error');
    const data = await UI.formModal({
      title: 'Record Treatment', submitLabel: 'Save Treatment',
      fields: [
        { name: 'animalId', label: 'Animal', type: 'select', options, full: true, required: true },
        { name: 'treatmentDate', label: 'Treatment Date', type: 'date', required: true, value: todayStr() },
        { name: 'medicineName', label: 'Medicine Name', required: true },
        { name: 'dose', label: 'Dose Administered' },
        { name: 'route', label: 'Route of Administration' },
        { name: 'withdrawalPeriod', label: 'Withdrawal Period (days)', type: 'number' },
        { name: 'milkWithdrawalPeriod', label: 'Milk Withdrawal (days)', type: 'number' },
        { name: 'meatWithdrawalPeriod', label: 'Meat Withdrawal (days)', type: 'number' },
        { name: 'repeatIntervalDays', label: 'Repeat Reminder (days, optional)', type: 'number', placeholder: 'e.g. 365 for annual' },
        { name: 'reason', label: 'Reason for Treatment', full: true },
        { name: 'notes', label: 'Notes', type: 'textarea' }
      ]
    });
    if (!data) return;
    const animal = await Api.getAnimal(data.animalId);
    data.species = animal.species;
    await Api.create('medicine', data);
    UI.toast('Treatment recorded.');
    dashboard();
  }

  async function quickAddBirth() {
    const females = await animalPickerOptions();
    if (!females.length) return UI.toast('Add a female animal first.', 'error');
    const data = await UI.formModal({
      title: 'Record Birth (Lamb/Calf)', submitLabel: 'Save Birth',
      fields: [
        { name: 'motherId', label: 'Mother', type: 'select', options: females, full: true, required: true },
        { name: 'tagNumber', label: 'New Animal Tag Number', required: true },
        { name: 'name', label: 'Name/Nickname' },
        { name: 'sex', label: 'Sex', type: 'select', options: [{ value: 'female', label: 'Female' }, { value: 'male', label: 'Male' }], required: true },
        { name: 'dob', label: 'Birth Date', type: 'date', required: true, value: todayStr() },
        { name: 'birthType', label: 'Birth Type', type: 'select', options: [{ value: 'single', label: 'Single' }, { value: 'twin', label: 'Twin' }, { value: 'triplet', label: 'Triplet' }, { value: 'quadruplet', label: 'Quadruplet' }] },
        { name: 'birthWeight', label: 'Birth Weight (kg)', type: 'number', step: '0.1' },
        { name: 'fatherId', label: 'Sire (tag/name, optional)' },
        { name: 'birthNotes', label: 'Birth Notes', type: 'textarea' }
      ]
    });
    if (!data) return;
    const mother = await Api.getAnimal(data.motherId);
    await Api.createAnimal({ ...data, species: mother.species, breed: mother.breed, status: 'active' });
    UI.toast(`${isCattle(mother.species) ? 'Calving' : 'Lambing'} recorded.`);
    dashboard();
  }

  async function quickAddMilk() {
    const options = await animalPickerOptions('cow');
    if (!options.length) return UI.toast('Add a cow first.', 'error');
    const data = await UI.formModal({
      title: 'Record Milking', submitLabel: 'Save',
      fields: [
        { name: 'cowId', label: 'Cow', type: 'select', options, full: true, required: true },
        { name: 'date', label: 'Date', type: 'date', required: true, value: todayStr() },
        { name: 'session', label: 'Session', type: 'select', options: [{ value: 'AM', label: 'AM' }, { value: 'PM', label: 'PM' }], required: true },
        { name: 'litres', label: 'Milk Yield (litres)', type: 'number', step: '0.1', required: true }
      ]
    });
    if (!data) return;
    await Api.create('milk', data);
    UI.toast('Milking recorded.');
    dashboard();
  }

  async function quickAddWeight() {
    const options = await animalPickerOptions();
    if (!options.length) return UI.toast('Add an animal first.', 'error');
    const data = await UI.formModal({
      title: 'Record Weight', submitLabel: 'Save',
      fields: [
        { name: 'animalId', label: 'Animal', type: 'select', options, full: true, required: true },
        { name: 'date', label: 'Date', type: 'date', required: true, value: todayStr() },
        { name: 'weight', label: 'Weight (kg)', type: 'number', step: '0.1', required: true },
        { name: 'notes', label: 'Notes', type: 'textarea' }
      ]
    });
    if (!data) return;
    await Api.create('weights', data);
    UI.toast('Weight recorded.');
    dashboard();
  }

  function todayStr() { return new Date().toISOString().slice(0, 10); }

  function getModules(settings) {
    const m = (settings && typeof settings.modules === 'object' && settings.modules) ? settings.modules : {};
    // Sheep and dairy cows are the app's original two modules and stay on
    // by default (opt-out). Suckler cows is a newer, more specialised
    // module so it starts off (opt-in) unless explicitly enabled.
    return { sheep: m.sheep !== false, cows: m.cows !== false, sucklers: m.sucklers === true };
  }

  // Print-only farm identification header — appears on printed reports and
  // animal records so paperwork handed to a vet, buyer, or inspector is
  // properly identified. Hidden on-screen (see .print-header in style.css);
  // only shows up in @media print.
  function printHeaderHtml(settings) {
    const s = settings || {};
    const idParts = [];
    if (s.holdingNumber) idParts.push(`Holding No: ${UI.esc(s.holdingNumber)}`);
    if (s.flockNumber) idParts.push(`Flock No: ${UI.esc(s.flockNumber)}`);
    if (s.herdNumber) idParts.push(`Herd No: ${UI.esc(s.herdNumber)}`);
    const hasAnything = s.farmName || s.farmAddress || idParts.length;
    if (!hasAnything) return '';

    return `
      <div class="print-header">
        ${s.farmName ? `<h2>${UI.esc(s.farmName)}</h2>` : ''}
        ${s.farmAddress ? `<div>${UI.esc(s.farmAddress).replace(/\n/g, '<br>')}</div>` : ''}
        ${idParts.length ? `<div>${idParts.join(' &nbsp;·&nbsp; ')}</div>` : ''}
        <div class="print-header-date">Printed ${new Date().toLocaleDateString()}</div>
      </div>
    `;
  }

  function daysBetweenDates(a, b) {
    if (!a || !b) return null;
    const da = new Date(a), db = new Date(b);
    if (isNaN(da.getTime()) || isNaN(db.getTime())) return null;
    return Math.round((db - da) / 86400000);
  }

  // After an "off the farm" movement with a reason that implies the animal
  // is no longer on the farm, offer to update its status to match — the
  // movement record itself is saved either way.
  const MOVEMENT_STATUS_SUGGESTIONS = { 'Sale': 'sold', 'Death': 'deceased', 'Slaughter/Abattoir': 'deceased' };
  async function maybeUpdateStatusAfterMovement(movementData, animal) {
    if (movementData.direction !== 'off') return;
    const suggested = MOVEMENT_STATUS_SUGGESTIONS[movementData.reason];
    if (!suggested || animal.status === suggested) return;
    const ok = await UI.confirmModal({
      title: 'Update animal status?',
      message: `Also mark ${animal.name || animal.tagNumber} as "${suggested}"?`,
      confirmLabel: `Mark as ${suggested}`,
      danger: false
    });
    if (ok) {
      await Api.updateAnimal(animal.id, { status: suggested });
      UI.toast('Status updated.');
    }
  }

  function movementFields(existing) {
    return [
      { name: 'direction', label: 'Direction', type: 'select', required: true, value: existing && existing.direction, options: [
        { value: 'on', label: 'Onto the farm (arriving)' },
        { value: 'off', label: 'Off the farm (leaving)' }
      ] },
      { name: 'date', label: 'Date', type: 'date', required: true, value: (existing && existing.date) || todayStr() },
      { name: 'reason', label: 'Reason', type: 'select', required: true, value: existing && existing.reason, options: [
        { value: 'Purchase', label: 'Purchase' },
        { value: 'Sale', label: 'Sale' },
        { value: 'Death', label: 'Death (on farm / collected)' },
        { value: 'Slaughter/Abattoir', label: 'Slaughter / Abattoir' },
        { value: 'Show/Exhibition', label: 'Show / Exhibition' },
        { value: 'Return', label: 'Return to farm' },
        { value: 'Other', label: 'Other' }
      ] },
      { name: 'location', label: 'Farm / Market / Abattoir Name', full: true, value: existing && existing.location },
      { name: 'locationReference', label: 'Holding Number / Reference (optional)', value: existing && existing.locationReference },
      { name: 'price', label: 'Price — cost if arriving, proceeds if leaving (optional)', type: 'number', step: '0.01', value: existing && existing.price },
      { name: 'transportedBy', label: 'Transported By (optional)', value: existing && existing.transportedBy },
      { name: 'notes', label: 'Notes', type: 'textarea', full: true, value: existing && existing.notes }
    ];
  }

  async function quickAddMovement() {
    const options = await animalPickerOptions();
    if (!options.length) return UI.toast('Add an animal first.', 'error');
    const fields = [{ name: 'animalId', label: 'Animal', type: 'select', options, full: true, required: true }].concat(movementFields());
    const data = await UI.formModal({ title: 'Record Movement', submitLabel: 'Save Movement', fields });
    if (!data) return;
    const animal = await Api.getAnimal(data.animalId);
    data.species = animal.species;
    await Api.create('movements', data);
    UI.toast('Movement recorded.');
    await maybeUpdateStatusAfterMovement(data, animal);
    dashboard();
  }

  // ================= ANIMAL LIST =================
  async function animalList(species) {
    await withLoading(async () => {
      const statuses = statusesFor(species);
      const params = new URLSearchParams(location.hash.split('?')[1] || '');
      const filters = { species, status: params.get('status') || '', sex: params.get('sex') || '', breed: params.get('breed') || '', group: params.get('group') || '', q: params.get('q') || '' };
      const [animals, allSpeciesAnimals] = await Promise.all([
        Api.listAnimals(filters),
        Api.listAnimals({ species })
      ]);
      const knownGroups = Array.from(new Set(allSpeciesAnimals.map(a => a.group).filter(Boolean))).sort();

      setHtml(`
        <div class="page-header">
          <div><h1>${speciesIcon(species)} ${herdLabel(species)}</h1><p class="subtitle">${animals.length} record(s)</p></div>
          <div class="btn-row">
            <a class="btn btn-primary" href="#/${routeFor(species)}/new"><i class="ti ti-plus"></i> Add ${speciesLabel(species)}</a>
            <a class="btn" href="${Api.exportCsvUrl('animals')}" target="_blank"><i class="ti ti-download"></i> Export All Animals CSV</a>
          </div>
        </div>

        <div class="card">
          <form id="filter-form" class="form-grid" style="grid-template-columns:repeat(5,1fr)">
            <div class="field"><label>Status</label>
              <select name="status"><option value="">All</option>${statuses.map(s => `<option value="${s}" ${filters.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
            </div>
            <div class="field"><label>Sex</label>
              <select name="sex"><option value="">All</option>${sexOptions(species).map(o => `<option value="${o.value}" ${filters.sex === o.value ? 'selected' : ''}>${o.label}</option>`).join('')}</select>
            </div>
            <div class="field"><label>Breed</label><input name="breed" value="${UI.esc(filters.breed)}" placeholder="e.g. Suffolk"></div>
            <div class="field"><label>Group / Mob</label>
              <input name="group" list="group-filter-suggestions" value="${UI.esc(filters.group)}" placeholder="Any">
              <datalist id="group-filter-suggestions">${knownGroups.map(g => `<option value="${UI.esc(g)}">`).join('')}</datalist>
            </div>
            <div class="field"><label>Search tag/name</label><input name="q" value="${UI.esc(filters.q)}" placeholder="Tag or name"></div>
          </form>
        </div>

        <div class="card">
          ${UI.table([
            { label: 'Tag', key: 'tagNumber' },
            { label: 'Name', key: 'name', render: r => UI.esc(r.name || '—') },
            { label: 'Sex', key: 'sex' },
            { label: 'Breed', key: 'breed' },
            { label: 'Group', key: 'group', render: r => UI.esc(r.group || '—') },
            { label: 'DOB', key: 'dob', render: r => UI.fmtDate(r.dob) },
            { label: 'Status', key: 'status', render: r => UI.badge(r.status) },
            { label: '', key: 'id', render: r => `<a class="btn btn-sm" href="#/${routeFor(species)}/${r.id}">View</a>` }
          ], animals.sort((a, b) => (a.tagNumber || '').localeCompare(b.tagNumber || '')), { emptyText: `No ${speciesLabelLower(species)} match these filters.` })}
        </div>
      `);

      document.getElementById('filter-form').addEventListener('change', (e) => {
        const form = e.currentTarget;
        const fd = new FormData(form);
        const qs = new URLSearchParams();
        for (const [k, v] of fd.entries()) if (v) qs.set(k, v);
        location.hash = `#/${routeFor(species)}${qs.toString() ? '?' + qs.toString() : ''}`;
      });
    });
  }

  // ================= ANIMAL FORM (create/edit) =================
  async function animalForm(species, id, prefill) {
    await withLoading(async () => {
      const isEdit = !!id;
      const animal = isEdit ? await Api.getAnimal(id) : Object.assign({}, prefill);
      const statuses = statusesFor(species);
      const speciesAnimals = await Api.listAnimals({ species });
      const mothers = speciesAnimals.filter(a => a.sex === 'female' && a.id !== id);
      const knownGroups = Array.from(new Set(speciesAnimals.map(a => a.group).filter(Boolean))).sort();

      setHtml(`
        <div class="page-header">
          <div><h1>${isEdit ? 'Edit' : 'Add'} ${speciesLabel(species)}</h1></div>
          <a class="btn" href="#/${routeFor(species)}"><i class="ti ti-arrow-left"></i> Back to list</a>
        </div>
        <div class="card">
          <form id="animal-form" class="form-grid">
            <div class="field"><label>Tag Number *</label><input name="tagNumber" required value="${UI.esc(animal.tagNumber)}"></div>
            <div class="field"><label>EID Number</label><input name="eidNumber" value="${UI.esc(animal.eidNumber)}"></div>
            <div class="field"><label>Name / Nickname</label><input name="name" value="${UI.esc(animal.name)}"></div>
            <div class="field"><label>Sex *</label>
              <select name="sex" required>${sexOptions(species).map(o => `<option value="${o.value}" ${animal.sex === o.value ? 'selected' : ''}>${o.label}</option>`).join('')}</select>
            </div>
            <div class="field"><label>Breed</label><input name="breed" value="${UI.esc(animal.breed)}"></div>
            <div class="field"><label>Date of Birth</label><input name="dob" type="date" value="${UI.esc(animal.dob)}"></div>
            <div class="field"><label>Status *</label>
              <select name="status" required>${statuses.map(s => `<option value="${s}" ${(animal.status || statuses[0]) === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
            </div>
            <div class="field"><label>Group / Mob (optional)</label>
              <input name="group" list="group-suggestions" placeholder="e.g. Triplet-bearing ewes" value="${UI.esc(animal.group)}">
              <datalist id="group-suggestions">${knownGroups.map(g => `<option value="${UI.esc(g)}">`).join('')}</datalist>
            </div>
            <div class="field"><label>Mother (Dam)</label>
              <select name="motherId"><option value="">— none / unknown —</option>${mothers.map(m => `<option value="${m.id}" ${animal.motherId === m.id ? 'selected' : ''}>${animalDisplay(m)}</option>`).join('')}</select>
            </div>
            <div class="field"><label>Sire (tag/name, optional)</label><input name="fatherId" value="${UI.esc(animal.fatherId)}"></div>
            <div class="field"><label>Birth Type</label>
              <select name="birthType"><option value="">—</option>${['single', 'twin', 'triplet', 'quadruplet'].map(t => `<option value="${t}" ${animal.birthType === t ? 'selected' : ''}>${t}</option>`).join('')}</select>
            </div>
            <div class="field"><label>Birth Weight (kg)</label><input name="birthWeight" type="number" step="0.1" value="${UI.esc(animal.birthWeight)}"></div>
            <div class="field full"><label>Birth Notes</label><textarea name="birthNotes">${UI.esc(animal.birthNotes)}</textarea></div>
            <div class="field full"><label>General Notes</label><textarea name="notes">${UI.esc(animal.notes)}</textarea></div>
          </form>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn btn-primary" id="save-animal"><i class="ti ti-device-floppy"></i> Save</button>
            ${isEdit ? `<button class="btn btn-danger" id="archive-animal"><i class="ti ti-archive"></i> Archive</button>` : ''}
          </div>
        </div>
      `);

      document.getElementById('save-animal').onclick = async () => {
        const form = document.getElementById('animal-form');
        if (!form.reportValidity()) return;
        const fd = new FormData(form);
        const data = Object.fromEntries(fd.entries());
        data.species = species;
        try {
          if (isEdit) {
            await Api.updateAnimal(id, data);
            UI.toast('Saved.');
            location.hash = `#/${routeFor(species)}/${id}`;
          } else {
            const created = await Api.createAnimal(data);
            UI.toast('Animal added.');
            location.hash = `#/${routeFor(species)}/${created.id}`;
          }
        } catch (e) { UI.toast(e.message, 'error'); }
      };

      if (isEdit) {
        document.getElementById('archive-animal').onclick = async () => {
          const ok = await UI.confirmModal({ title: 'Archive this animal?', message: 'The record is kept but hidden from active lists. This is not a permanent delete.', confirmLabel: 'Archive' });
          if (!ok) return;
          await Api.archiveAnimal(id);
          UI.toast('Animal archived.');
          location.hash = `#/${routeFor(species)}`;
        };
      }
    });
  }

  // ================= ANIMAL PROFILE =================
  let currentProfileTab = 'overview';

  async function animalProfile(id, tab) {
    currentProfileTab = tab || currentProfileTab || 'overview';
    await withLoading(async () => {
      const animal = await Api.getAnimal(id);
      const species = animal.species;
      const listRoute = routeFor(species);
      const isCow = isCattle(species);
      const showMilk = hasMilk(species);

      const [breeding, medicine, weights, milk, milktests, movements, offspring, mother, settings] = await Promise.all([
        Api.list('breeding'), Api.list('medicine'), Api.list('weights'),
        showMilk ? Api.list('milk') : Promise.resolve([]),
        showMilk ? Api.list('milktests') : Promise.resolve([]),
        Api.list('movements'),
        Api.offspringOf(id),
        animal.motherId ? Api.getAnimal(animal.motherId).catch(() => null) : Promise.resolve(null),
        Api.getSettings()
      ]);

      const myBreeding = breeding.filter(b => b.animalId === id);
      const myMedicine = medicine.filter(m => m.animalId === id);
      const myWeights = weights.filter(w => w.animalId === id).sort((a, b) => new Date(a.date) - new Date(b.date));
      const myMilk = showMilk ? milk.filter(m => m.cowId === id).sort((a, b) => new Date(a.date) - new Date(b.date)) : [];
      const myMilkTests = showMilk ? milktests.filter(m => m.cowId === id).sort((a, b) => new Date(a.date) - new Date(b.date)) : [];
      const myMovements = movements.filter(mv => mv.animalId === id);

      const activeWithdrawal = myMedicine.filter(m => {
        const t = todayStr();
        return (m.withdrawalEndDate && m.withdrawalEndDate >= t) || (m.milkWithdrawalEndDate && m.milkWithdrawalEndDate >= t) || (m.meatWithdrawalEndDate && m.meatWithdrawalEndDate >= t);
      });

      const tabs = [
        ['overview', 'Overview'],
        ['breeding', isCow ? 'Breeding & Calving' : 'Breeding & Lambing'],
        ['medicine', 'Medicine'],
        ['weights', 'Weights'],
        ['movements', 'Movements'],
        ...(showMilk ? [['milk', 'Milk'], ['milktests', 'Milk Tests']] : []),
        ['timeline', 'Timeline']
      ];

      setHtml(`
        ${printHeaderHtml(settings)}
        <div class="page-header">
          <div>
            <h1>${UI.esc(animalDisplay(animal))} <span class="badge badge-${animal.status}">${UI.esc(animal.status)}</span></h1>
            <p class="subtitle">Tag ${UI.esc(animal.tagNumber)} ${animal.eidNumber ? `· EID ${UI.esc(animal.eidNumber)}` : ''} · ${UI.esc(animal.breed || 'Unknown breed')} · ${animal.sex}${animal.group ? ` · Group: ${UI.esc(animal.group)}` : ''}</p>
          </div>
          <div class="btn-row">
            ${activeWithdrawal.length ? `<span class="badge" style="background:#f3d9cf;color:#8a3b1f"><i class="ti ti-alert-triangle"></i> Under withdrawal</span>` : ''}
            <a class="btn" href="#/${listRoute}/${id}/edit"><i class="ti ti-edit"></i> Edit</a>
            <button class="btn no-print" id="print-profile"><i class="ti ti-printer"></i> Print</button>
            <a class="btn" href="#/${listRoute}"><i class="ti ti-arrow-left"></i> Back</a>
          </div>
        </div>

        <div class="tabs" id="profile-tabs">
          ${tabs.map(([key, label]) => `<button class="tab-btn ${currentProfileTab === key ? 'active' : ''}" data-tab="${key}">${label}</button>`).join('')}
        </div>

        <div id="tab-content"></div>
      `);

      document.getElementById('print-profile').onclick = () => window.print();
      document.querySelectorAll('#profile-tabs .tab-btn').forEach(btn => {
        btn.onclick = () => { currentProfileTab = btn.dataset.tab; location.hash = `#/${listRoute}/${id}/${currentProfileTab}`; renderTab(); };
      });

      function renderTab() {
        document.querySelectorAll('#profile-tabs .tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === currentProfileTab));
        const el = document.getElementById('tab-content');
        if (currentProfileTab === 'overview') return renderOverview(el);
        if (currentProfileTab === 'breeding') return renderBreeding(el);
        if (currentProfileTab === 'medicine') return renderMedicine(el);
        if (currentProfileTab === 'weights') return renderWeights(el);
        if (currentProfileTab === 'movements') return renderMovements(el);
        if (currentProfileTab === 'milk' && showMilk) return renderMilk(el);
        if (currentProfileTab === 'milktests' && showMilk) return renderMilkTests(el);
        if (currentProfileTab === 'timeline') return renderTimeline(el);
      }

      function renderOverview(el) {
        const purchaseMv = myMovements.find(mv => mv.reason === 'Purchase');
        const saleMv = myMovements.find(mv => mv.reason === 'Sale');
        const purchasePrice = purchaseMv && purchaseMv.price !== undefined && purchaseMv.price !== null && purchaseMv.price !== '' ? Number(purchaseMv.price) : null;
        const salePrice = saleMv && saleMv.price !== undefined && saleMv.price !== null && saleMv.price !== '' ? Number(saleMv.price) : null;

        // Days on farm: purchase date (or date of birth, if born here) through
        // to the sale date, or through to today if still on the farm.
        const startDate = (purchaseMv && purchaseMv.date) || animal.dob || null;
        const endDate = (saleMv && saleMv.date) || todayStr();
        const days = startDate ? daysBetweenDates(startDate, endDate) : null;
        const hasMovementEconomics = !!(purchaseMv || saleMv);

        el.innerHTML = `
          <div class="grid grid-2">
            <div class="card">
              <h3 style="margin-top:0">Parentage</h3>
              ${mother ? `<p>Dam: <a href="#/${routeFor(mother.species)}/${mother.id}">${UI.esc(animalDisplay(mother))}</a></p>` : '<p>Dam: unknown</p>'}
              <p>Sire: ${UI.esc(animal.fatherId || 'unknown')}</p>
              ${animal.birthType ? `<p>Birth type: ${UI.esc(animal.birthType)}</p>` : ''}
              ${animal.birthWeight ? `<p>Birth weight: ${UI.esc(animal.birthWeight)} kg</p>` : ''}
              ${animal.birthNotes ? `<p>Birth notes: ${UI.esc(animal.birthNotes)}</p>` : ''}
            </div>
            <div class="card">
              <h3 style="margin-top:0">Offspring (${offspring.length})</h3>
              ${offspring.length ? `<div class="link-list">${offspring.map(o => `<a href="#/${routeFor(o.species)}/${o.id}">${UI.esc(animalDisplay(o))} — born ${UI.fmtDate(o.dob)}</a>`).join('')}</div>` : UI.emptyState('No offspring recorded.')}
            </div>
          </div>
          <div class="card" id="overview-econ-card">
            <h3 style="margin-top:0">Purchase / Sale / Feed</h3>
            <div class="empty-state" style="padding:16px 0">Loading feed cost…</div>
          </div>
          <div class="card">
            <h3 style="margin-top:0">Notes</h3>
            <p>${UI.esc(animal.notes) || '<span style="color:var(--text-dim)">No notes.</span>'}</p>
          </div>
        `;

        Api.animalFeedCost(id).then(feedResult => {
          const econCard = el.querySelector('#overview-econ-card');
          if (!econCard) return; // user already switched tabs before this resolved

          const feedCost = feedResult.total || 0;
          const feedEntries = feedResult.entries || [];
          const hasEconomics = hasMovementEconomics || feedEntries.length > 0;
          if (!hasEconomics) { econCard.remove(); return; }

          const profit = (purchasePrice !== null && salePrice !== null) ? (salePrice - purchasePrice - feedCost) : null;
          const spentSoFar = (!saleMv && (purchasePrice !== null || feedCost > 0)) ? (purchasePrice || 0) + feedCost : null;

          const statCards = [];
          if (hasMovementEconomics) statCards.push(UI.statCard('Purchase Price', purchasePrice !== null ? `£${purchasePrice.toFixed(2)}` : '—'));
          if (days !== null) statCards.push(UI.statCard('Days on Farm', days));
          statCards.push(UI.statCard('Feed Cost (direct)', `£${feedCost.toFixed(2)}`));
          if (hasMovementEconomics) statCards.push(UI.statCard('Sale Price', salePrice !== null ? `£${salePrice.toFixed(2)}` : '—'));
          if (profit !== null) {
            statCards.push(UI.statCard('Profit / Loss (after feed)', `£${profit.toFixed(2)}`, profit >= 0 ? '' : 'danger'));
          } else if (spentSoFar !== null) {
            statCards.push(UI.statCard('Total Spent So Far', `£${spentSoFar.toFixed(2)}`));
          }

          econCard.innerHTML = `
            <h3 style="margin-top:0">Purchase / Sale / Feed</h3>
            <div class="grid grid-3">${statCards.join('')}</div>
            <p style="color:var(--text-dim);font-size:0.87rem;margin:10px 0 0">
              ${purchaseMv ? `Purchased ${UI.fmtDate(purchaseMv.date)}${purchaseMv.location ? ' from ' + UI.esc(purchaseMv.location) : ''}. ` : ''}
              ${saleMv ? `Sold ${UI.fmtDate(saleMv.date)}${saleMv.location ? ' to ' + UI.esc(saleMv.location) : ''}. ` : ''}
              ${myMovements.length ? '<a href="#" data-goto-movements>See movement history →</a> ' : ''}
              ${feedEntries.length ? '<a href="#/feed">See feed records →</a>' : ''}
            </p>
            ${feedEntries.length ? `
            <div class="table-wrap" style="margin-top:12px">
              ${UI.table([
                { label: 'Date', key: 'date', render: r => UI.fmtDate(r.date) },
                { label: 'Product', key: 'product' },
                { label: 'Quantity', key: 'quantity', render: r => `${r.quantity} ${r.unit || ''}`.trim() },
                { label: 'Cost', key: 'cost', render: r => `£${Number(r.cost).toFixed(2)}` }
              ], feedEntries, { emptyText: '' })}
            </div>` : ''}
          `;

          const gotoLink = econCard.querySelector('[data-goto-movements]');
          if (gotoLink) {
            gotoLink.onclick = (e) => {
              e.preventDefault();
              currentProfileTab = 'movements';
              location.hash = `#/${listRoute}/${id}/movements`;
              renderTab();
            };
          }
        }).catch(() => {
          const econCard = el.querySelector('#overview-econ-card');
          if (econCard && hasMovementEconomics) {
            econCard.innerHTML = `<h3 style="margin-top:0">Purchase / Sale / Feed</h3><p style="color:var(--text-dim)">Could not load feed cost.</p>`;
          } else if (econCard) {
            econCard.remove();
          }
        });
      }

      function renderBreeding(el) {
        const scanLabels = { empty: 'Empty', single: 'Single', twin: 'Twin', triplet: 'Triplet', quad: 'Quad+' };
        el.innerHTML = `
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px"><button class="btn btn-primary" id="add-breeding"><i class="ti ti-plus"></i> Add ${isCow ? 'Breeding/Calving' : 'Tupping/Lambing'} Record</button></div>
            ${UI.table([
              { label: isCow ? 'Service Date' : 'Tupping Date', key: 'eventDate', render: r => UI.fmtDate(r.eventDate) },
              { label: isCow ? 'Bull' : 'Ram', key: 'sireInfo' },
              ...(isCow ? [{ label: 'Method', key: 'method' }] : []),
              ...(!isCow ? [
                { label: 'Scan Date', key: 'scanDate', render: r => UI.fmtDate(r.scanDate) },
                { label: 'Scan Result', key: 'scanResult', render: r => r.scanResult ? scanLabels[r.scanResult] || r.scanResult : '—' }
              ] : []),
              { label: 'Expected', key: 'expectedDate', render: r => UI.fmtDate(r.expectedDate) },
              { label: 'Actual', key: 'actualDate', render: r => UI.fmtDate(r.actualDate) },
              ...(isCow ? [{ label: 'Pregnancy Check', key: 'pregnancyCheckResult' }] : []),
              { label: 'Notes', key: 'notes', wrap: true },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm" data-edit-breeding="${r.id}">Edit</button> <button class="btn btn-sm btn-danger" data-del-breeding="${r.id}">Del</button>` }
            ], myBreeding.sort((a, b) => new Date(b.eventDate) - new Date(a.eventDate)), { emptyText: 'No breeding records yet.' })}
          </div>
        `;
        el.querySelector('#add-breeding').onclick = () => breedingFormModal();
        el.querySelectorAll('[data-edit-breeding]').forEach(btn => btn.onclick = () => breedingFormModal(myBreeding.find(b => b.id === btn.dataset.editBreeding)));
        el.querySelectorAll('[data-del-breeding]').forEach(btn => btn.onclick = () => deleteRecord('breeding', btn.dataset.delBreeding));

        async function breedingFormModal(existing) {
          const data = await UI.formModal({
            title: existing ? 'Edit Breeding Record' : `Record ${isCow ? 'Service' : 'Tupping'}`,
            submitLabel: 'Save',
            fields: [
              { name: 'eventDate', label: isCow ? 'Service Date' : 'Tupping Date', type: 'date', required: true, value: existing?.eventDate },
              ...(isCow ? [{ name: 'method', label: 'Method', type: 'select', options: [{ value: 'natural', label: 'Natural' }, { value: 'AI', label: 'AI' }], value: existing?.method }] : []),
              { name: 'sireInfo', label: isCow ? 'Bull Used' : 'Ram Used', value: existing?.sireInfo },
              ...(!isCow ? [
                { name: 'scanDate', label: 'Scan Date (optional)', type: 'date', value: existing?.scanDate },
                { name: 'scanResult', label: 'Scan Result', type: 'select', value: existing?.scanResult, options: [
                  { value: '', label: '— Not scanned yet —' },
                  { value: 'empty', label: 'Empty (not in lamb)' },
                  { value: 'single', label: 'Single' },
                  { value: 'twin', label: 'Twin' },
                  { value: 'triplet', label: 'Triplet' },
                  { value: 'quad', label: 'Quad+' }
                ] }
              ] : []),
              { name: 'expectedDate', label: isCow ? 'Expected Calving Date' : 'Expected Lambing Date', type: 'date', value: existing?.expectedDate },
              { name: 'actualDate', label: isCow ? 'Actual Calving Date' : 'Actual Lambing Date', type: 'date', value: existing?.actualDate },
              ...(isCow ? [{ name: 'pregnancyCheckResult', label: 'Pregnancy Check Result', value: existing?.pregnancyCheckResult }] : []),
              { name: 'notes', label: 'Notes', type: 'textarea', full: true, value: existing?.notes }
            ]
          });
          if (!data) return;
          data.animalId = id; data.species = species;
          if (existing) await Api.update('breeding', existing.id, data); else await Api.create('breeding', data);
          UI.toast('Saved.');
          animalProfile(id, 'breeding');
        }
      }

      function renderMedicine(el) {
        el.innerHTML = `
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px">
              <button class="btn btn-primary" id="add-medicine"><i class="ti ti-plus"></i> Add Treatment</button>
              <a class="btn" href="${Api.exportCsvUrl('medicine')}" target="_blank"><i class="ti ti-download"></i> Export All Medicine CSV</a>
            </div>
            ${UI.table([
              { label: 'Date', key: 'treatmentDate', render: r => UI.fmtDate(r.treatmentDate) },
              { label: 'Medicine', key: 'medicineName' },
              { label: 'Dose', key: 'dose' },
              { label: 'Route', key: 'route' },
              { label: 'Reason', key: 'reason', wrap: true },
              { label: 'Withdrawal Ends', key: 'withdrawalEndDate', render: r => withdrawalCell(r) },
              { label: 'Next Due', key: 'nextDueDate', render: r => nextDueCell(r) },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm" data-edit-med="${r.id}">Edit</button> <button class="btn btn-sm btn-danger" data-del-med="${r.id}">Del</button>` }
            ], myMedicine.sort((a, b) => new Date(b.treatmentDate) - new Date(a.treatmentDate)), { emptyText: 'No treatments recorded yet.' })}
          </div>
        `;
        function withdrawalCell(r) {
          const t = todayStr();
          const dates = [r.withdrawalEndDate, r.milkWithdrawalEndDate, r.meatWithdrawalEndDate].filter(Boolean);
          if (!dates.length) return '—';
          const active = dates.some(d => d >= t);
          return `<span style="color:${active ? 'var(--red-500)' : 'var(--text-dim)'}">${dates.map(UI.fmtDate).join(' / ')}</span>`;
        }
        function nextDueCell(r) {
          if (!r.nextDueDate) return '—';
          const t = todayStr();
          const overdue = r.nextDueDate < t;
          return `<span style="color:${overdue ? 'var(--red-500)' : 'var(--text-dim)'}">${UI.fmtDate(r.nextDueDate)}${overdue ? ' (overdue)' : ''}</span>`;
        }
        el.querySelector('#add-medicine').onclick = () => medFormModal();
        el.querySelectorAll('[data-edit-med]').forEach(btn => btn.onclick = () => medFormModal(myMedicine.find(m => m.id === btn.dataset.editMed)));
        el.querySelectorAll('[data-del-med]').forEach(btn => btn.onclick = () => deleteRecord('medicine', btn.dataset.delMed));

        async function medFormModal(existing) {
          const data = await UI.formModal({
            title: existing ? 'Edit Treatment' : 'Record Treatment', submitLabel: 'Save',
            fields: [
              { name: 'treatmentDate', label: 'Treatment Date', type: 'date', required: true, value: existing?.treatmentDate || todayStr() },
              { name: 'medicineName', label: 'Medicine Name', required: true, value: existing?.medicineName },
              { name: 'dose', label: 'Dose Administered', value: existing?.dose },
              { name: 'route', label: 'Route of Administration', value: existing?.route },
              { name: 'withdrawalPeriod', label: 'Withdrawal Period (days)', type: 'number', value: existing?.withdrawalPeriod },
              { name: 'milkWithdrawalPeriod', label: 'Milk Withdrawal (days)', type: 'number', value: existing?.milkWithdrawalPeriod },
              { name: 'meatWithdrawalPeriod', label: 'Meat Withdrawal (days)', type: 'number', value: existing?.meatWithdrawalPeriod },
              { name: 'repeatIntervalDays', label: 'Repeat Reminder (days, optional)', type: 'number', placeholder: 'e.g. 365 for annual', value: existing?.repeatIntervalDays },
              { name: 'reason', label: 'Reason for Treatment', full: true, value: existing?.reason },
              { name: 'notes', label: 'Notes', type: 'textarea', value: existing?.notes }
            ]
          });
          if (!data) return;
          data.animalId = id; data.species = species;
          if (existing) await Api.update('medicine', existing.id, data); else await Api.create('medicine', data);
          UI.toast('Saved.');
          animalProfile(id, 'medicine');
        }
      }

      function renderWeights(el) {
        const points = myWeights.map(w => ({ x: w.date, y: Number(w.weight) }));
        el.innerHTML = `
          <div class="card">
            <h3 style="margin-top:0">Growth Chart</h3>
            ${UI.lineChart({ points })}
          </div>
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px"><button class="btn btn-primary" id="add-weight"><i class="ti ti-plus"></i> Add Weight</button></div>
            ${UI.table([
              { label: 'Date', key: 'date', render: r => UI.fmtDate(r.date) },
              { label: 'Weight (kg)', key: 'weight' },
              { label: 'Notes', key: 'notes', wrap: true },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm btn-danger" data-del-weight="${r.id}">Del</button>` }
            ], myWeights.slice().reverse(), { emptyText: 'No weight records yet.' })}
          </div>
        `;
        el.querySelector('#add-weight').onclick = async () => {
          const data = await UI.formModal({
            title: 'Add Weight', submitLabel: 'Save',
            fields: [
              { name: 'date', label: 'Date', type: 'date', required: true, value: todayStr() },
              { name: 'weight', label: 'Weight (kg)', type: 'number', step: '0.1', required: true },
              { name: 'notes', label: 'Notes', type: 'textarea' }
            ]
          });
          if (!data) return;
          data.animalId = id;
          await Api.create('weights', data);
          UI.toast('Saved.');
          animalProfile(id, 'weights');
        };
        el.querySelectorAll('[data-del-weight]').forEach(btn => btn.onclick = () => deleteRecord('weights', btn.dataset.delWeight));
      }

      function renderMovements(el) {
        el.innerHTML = `
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px">
              <button class="btn btn-primary" id="add-movement"><i class="ti ti-plus"></i> Add Movement</button>
              <a class="btn" href="${Api.exportCsvUrl('movements')}" target="_blank"><i class="ti ti-download"></i> Export All Movements CSV</a>
            </div>
            ${UI.table([
              { label: 'Date', key: 'date', render: r => UI.fmtDate(r.date) },
              { label: 'Direction', key: 'direction', render: r => r.direction === 'on' ? 'Onto farm' : 'Off farm' },
              { label: 'Reason', key: 'reason' },
              { label: 'Location', key: 'location' },
              { label: 'Reference', key: 'locationReference' },
              { label: 'Price', key: 'price', render: r => r.price !== undefined && r.price !== null && r.price !== '' ? `£${Number(r.price).toFixed(2)}` : '—' },
              { label: 'Notes', key: 'notes', wrap: true },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm" data-edit-mv="${r.id}">Edit</button> <button class="btn btn-sm btn-danger" data-del-mv="${r.id}">Del</button>` }
            ], myMovements.slice().sort((a, b) => new Date(b.date) - new Date(a.date)), { emptyText: 'No movements recorded yet.' })}
          </div>
        `;
        el.querySelector('#add-movement').onclick = () => movementModal();
        el.querySelectorAll('[data-edit-mv]').forEach(btn => btn.onclick = () => movementModal(myMovements.find(m => m.id === btn.dataset.editMv)));
        el.querySelectorAll('[data-del-mv]').forEach(btn => btn.onclick = () => deleteRecord('movements', btn.dataset.delMv));

        async function movementModal(existing) {
          const data = await UI.formModal({
            title: existing ? 'Edit Movement' : 'Record Movement', submitLabel: 'Save',
            fields: movementFields(existing)
          });
          if (!data) return;
          data.animalId = id; data.species = species;
          if (existing) await Api.update('movements', existing.id, data); else await Api.create('movements', data);
          UI.toast('Saved.');
          if (!existing) await maybeUpdateStatusAfterMovement(data, animal);
          animalProfile(id, 'movements');
        }
      }

      function renderMilk(el) {
        const byDate = {};
        myMilk.forEach(m => { byDate[m.date] = (byDate[m.date] || 0) + Number(m.litres || 0); });
        const points = Object.keys(byDate).sort().map(d => ({ x: d, y: Math.round(byDate[d] * 100) / 100 }));
        el.innerHTML = `
          <div class="card">
            <h3 style="margin-top:0">Daily Milk Yield</h3>
            ${UI.lineChart({ points })}
          </div>
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px">
              <button class="btn btn-primary" id="add-milk"><i class="ti ti-plus"></i> Add Milking</button>
              <a class="btn" href="${Api.exportCsvUrl('milk')}" target="_blank"><i class="ti ti-download"></i> Export All Milk CSV</a>
            </div>
            ${UI.table([
              { label: 'Date', key: 'date', render: r => UI.fmtDate(r.date) },
              { label: 'Session', key: 'session' },
              { label: 'Litres', key: 'litres' },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm btn-danger" data-del-milk="${r.id}">Del</button>` }
            ], myMilk.slice().reverse().slice(0, 60), { emptyText: 'No milking records yet.' })}
          </div>
        `;
        el.querySelector('#add-milk').onclick = async () => {
          const data = await UI.formModal({
            title: 'Add Milking', submitLabel: 'Save',
            fields: [
              { name: 'date', label: 'Date', type: 'date', required: true, value: todayStr() },
              { name: 'session', label: 'Session', type: 'select', options: [{ value: 'AM', label: 'AM' }, { value: 'PM', label: 'PM' }], required: true },
              { name: 'litres', label: 'Litres', type: 'number', step: '0.1', required: true }
            ]
          });
          if (!data) return;
          data.cowId = id;
          await Api.create('milk', data);
          UI.toast('Saved.');
          animalProfile(id, 'milk');
        };
        el.querySelectorAll('[data-del-milk]').forEach(btn => btn.onclick = () => deleteRecord('milk', btn.dataset.delMilk));
      }

      function renderMilkTests(el) {
        const bfPoints = myMilkTests.map(m => ({ x: m.date, y: Number(m.butterfat) || 0 }));
        el.innerHTML = `
          <div class="card"><h3 style="margin-top:0">Butterfat % Trend</h3>${UI.lineChart({ points: bfPoints })}</div>
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px"><button class="btn btn-primary" id="add-milktest"><i class="ti ti-plus"></i> Add Milk Test</button></div>
            ${UI.table([
              { label: 'Date', key: 'date', render: r => UI.fmtDate(r.date) },
              { label: 'Butterfat %', key: 'butterfat' },
              { label: 'Protein %', key: 'protein' },
              { label: 'SCC', key: 'scc', render: r => `<span style="color:${Number(r.scc) > 200000 ? 'var(--red-500)' : 'inherit'}">${UI.esc(r.scc)}</span>` },
              { label: 'Notes', key: 'notes', wrap: true },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm btn-danger" data-del-mt="${r.id}">Del</button>` }
            ], myMilkTests.slice().reverse(), { emptyText: 'No milk test results yet.' })}
          </div>
        `;
        el.querySelector('#add-milktest').onclick = async () => {
          const data = await UI.formModal({
            title: 'Add Milk Test', submitLabel: 'Save',
            fields: [
              { name: 'date', label: 'Test Date', type: 'date', required: true, value: todayStr() },
              { name: 'butterfat', label: 'Butterfat %', type: 'number', step: '0.1' },
              { name: 'protein', label: 'Protein %', type: 'number', step: '0.1' },
              { name: 'scc', label: 'Somatic Cell Count', type: 'number' },
              { name: 'notes', label: 'Notes', type: 'textarea' }
            ]
          });
          if (!data) return;
          data.cowId = id;
          await Api.create('milktests', data);
          UI.toast('Saved.');
          animalProfile(id, 'milktests');
        };
        el.querySelectorAll('[data-del-mt]').forEach(btn => btn.onclick = () => deleteRecord('milktests', btn.dataset.delMt));
      }

      function renderTimeline(el) {
        el.innerHTML = `<div class="card"><h3 style="margin-top:0">Complete Timeline</h3><div id="timeline-wrap"></div></div>`;
        Api.timelineOf(id).then(events => {
          const wrap = el.querySelector('#timeline-wrap');
          if (!events.length) { wrap.innerHTML = UI.emptyState('No events recorded yet.'); return; }
          wrap.innerHTML = `<div class="timeline">${events.map(e => `
            <div class="timeline-item">
              <div class="timeline-date">${UI.fmtDate(e.date)}</div>
              <div class="timeline-label">${UI.esc(e.label)}</div>
              ${e.detail ? `<div class="timeline-detail">${UI.esc(e.detail)}</div>` : ''}
            </div>`).join('')}</div>`;
        });
      }

      async function deleteRecord(collection, recId) {
        const ok = await UI.confirmModal({ title: 'Delete this record?', message: 'This cannot be undone.', confirmLabel: 'Delete' });
        if (!ok) return;
        await Api.remove(collection, recId);
        UI.toast('Deleted.');
        animalProfile(id, currentProfileTab);
      }

      renderTab();
    });
  }

  // ================= MILK RECORDING (global) =================
  async function milkView() {
    await withLoading(async () => {
      const [cows, herdDaily] = await Promise.all([Api.listAnimals({ species: 'cow' }), Api.herdDaily()]);
      const milkingCows = cows.filter(c => c.status !== 'archived');
      const points = herdDaily.slice(-30).map(d => ({ x: d.date, y: d.litres }));

      const summaries = await Promise.all(milkingCows.map(async c => ({ cow: c, summary: await Api.milkSummaryForCow(c.id) })));

      setHtml(`
        <div class="page-header">
          <div><h1><i class="ti ti-droplet"></i> Milk Recording</h1><p class="subtitle">Herd milk production, tests and trends</p></div>
          <div class="btn-row">
            <button class="btn btn-primary" id="add-milk-global"><i class="ti ti-plus"></i> Record Milking</button>
            <a class="btn" href="${Api.exportCsvUrl('milk')}" target="_blank"><i class="ti ti-download"></i> Export CSV</a>
          </div>
        </div>

        <div class="card">
          <h3 style="margin-top:0">Herd Daily Total (last 30 days)</h3>
          ${UI.lineChart({ points })}
        </div>

        <div class="card">
          <h3 style="margin-top:0">Per-Cow Averages</h3>
          ${UI.table([
            { label: 'Cow', key: 'name', render: r => `<a href="#/cows/${r.cow.id}">${UI.esc(animalDisplay(r.cow))}</a>` },
            { label: 'Status', key: 'status', render: r => UI.badge(r.cow.status) },
            { label: "Today (L)", key: 'today', render: r => r.summary.todayTotal },
            { label: '7-day avg', key: 'avg7', render: r => r.summary.avg7 },
            { label: '30-day avg', key: 'avg30', render: r => r.summary.avg30 },
            { label: 'Lactation avg', key: 'avgLactation', render: r => r.summary.avgLactation },
            { label: '', key: 'flag', render: r => r.summary.dropAlert ? `<span class="badge" style="background:#f3d9cf;color:#8a3b1f"><i class="ti ti-alert-triangle"></i> Yield drop</span>` : '' }
          ], summaries, { emptyText: 'No cows recorded yet.' })}
        </div>
      `);

      document.getElementById('add-milk-global').onclick = async () => {
        await quickAddMilk();
        milkView();
      };
    });
  }

  // ================= REPORTS =================
  const REPORTS = [
    { group: 'Sheep', module: 'sheep', items: [
      ['lambing-summary', 'Lambing Summary'],
      ['ewe-productivity', 'Ewe Productivity'],
      ['treatment-history', 'Treatment History (all animals)'],
      ['mortality-report', 'Mortality Report'],
      ['flock-inventory', 'Flock Inventory'],
      ['flock-performance-kpis', 'Flock Performance KPIs (Scanning % / Lambing %)'],
      ['barren-cull-candidates', 'Barren Ewes / Cull Candidates']
    ]},
    { group: 'Dairy Milk', module: 'cows', items: [
      ['milk-production-summary', 'Milk Production Summary'],
      ['butterfat-protein-summary', 'Butterfat & Protein Summary'],
      ['cell-count-report', 'Cell Count Report']
    ]},
    { group: 'Cattle', module: ['cows', 'sucklers'], items: [
      ['calving-report', 'Calving Report'],
      ['herd-inventory', 'Herd Inventory']
    ]},
    { group: 'Farm', module: null, items: [
      ['movement-log', 'Movement Log (all animals)'],
      ['purchase-sale-summary', 'Purchase & Sale Summary'],
      ['feed-cost-summary', 'Feed Cost Summary']
    ]}
  ];

  async function reportsView(reportName) {
    await withLoading(async () => {
      const settings = await Api.getSettings();
      const modules = getModules(settings);
      const visibleGroups = REPORTS.filter(g => !g.module || (Array.isArray(g.module) ? g.module.some(m => modules[m]) : modules[g.module]));

      const listHtml = visibleGroups.map(g => `
        <div class="card">
          <h3 style="margin-top:0">${g.group}</h3>
          <div class="btn-row">
            ${g.items.map(([key, label]) => `<a class="btn ${reportName === key ? 'btn-primary' : ''}" href="#/reports/${key}">${label}</a>`).join('')}
          </div>
        </div>
      `).join('');

      setHtml(`
        <div class="page-header"><div><h1><i class="ti ti-clipboard-list"></i> Reports</h1><p class="subtitle">Generate a farm report</p></div></div>
        <div class="grid grid-2">${listHtml}</div>
        <div id="report-output"></div>
      `);

      if (!reportName) return;
      const report = await Api.report(reportName);
      const out = document.getElementById('report-output');
      const rows = report.rows;
      const columns = rows.length ? Object.keys(rows[0]).map(k => ({ label: k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase()), key: k })) : [];
      out.innerHTML = `
        <div class="card">
          ${printHeaderHtml(settings)}
          <div class="page-header" style="margin-bottom:10px">
            <h3 style="margin:0">${UI.esc(report.title)}</h3>
            <div class="btn-row no-print">
              <button class="btn" id="print-report"><i class="ti ti-printer"></i> Print</button>
            </div>
          </div>
          ${UI.table(columns, rows, { emptyText: 'No data available for this report yet.' })}
        </div>
      `;
      document.getElementById('print-report').onclick = () => window.print();
    });
  }

  // ================= BACKUP / RESTORE =================
  async function dataView() {
    await withLoading(async () => {
      setHtml(`
        <div class="page-header"><div><h1><i class="ti ti-device-floppy"></i> Backup &amp; Restore</h1><p class="subtitle">Export your farm data or restore from a backup file</p></div></div>

        <div class="card">
          <h3 style="margin-top:0">Full Backup (JSON)</h3>
          <p>Downloads every record in the system as a single JSON file. Keep copies somewhere safe (USB drive, cloud folder, email to yourself).</p>
          <a class="btn btn-primary" href="${Api.exportJsonUrl()}"><i class="ti ti-download"></i> Download Full Backup</a>
        </div>

        <div class="card">
          <h3 style="margin-top:0">Restore from Backup</h3>
          <p>Choose a previously exported JSON backup file. <strong>This will overwrite all current data.</strong></p>
          <input type="file" id="restore-file" accept="application/json">
          <div class="btn-row" style="margin-top:10px"><button class="btn btn-danger" id="restore-btn">Restore Backup</button></div>
        </div>

        <div class="card">
          <h3 style="margin-top:0">CSV Exports</h3>
          <p>Export individual record types as CSV for spreadsheets or printing.</p>
          <div class="btn-row">
            <a class="btn" href="${Api.exportCsvUrl('animals')}" target="_blank">Animals (Sheep + Cows)</a>
            <a class="btn" href="${Api.exportCsvUrl('breeding')}" target="_blank">Breeding Records</a>
            <a class="btn" href="${Api.exportCsvUrl('medicine')}" target="_blank">Medicine Records</a>
            <a class="btn" href="${Api.exportCsvUrl('weights')}" target="_blank">Weight Records</a>
            <a class="btn" href="${Api.exportCsvUrl('milk')}" target="_blank">Milk Records</a>
            <a class="btn" href="${Api.exportCsvUrl('milktests')}" target="_blank">Milk Test Records</a>
            <a class="btn" href="${Api.exportCsvUrl('movements')}" target="_blank">Movement Records</a>
            <a class="btn" href="${Api.exportCsvUrl('feedproducts')}" target="_blank">Feed Products</a>
            <a class="btn" href="${Api.exportCsvUrl('feedpurchases')}" target="_blank">Feed Purchases</a>
            <a class="btn" href="${Api.exportCsvUrl('feedusage')}" target="_blank">Feed Usage</a>
          </div>
        </div>

        <div class="card">
          <h3 style="margin-top:0">Automatic Backups</h3>
          <p>Every save also writes a rolling internal backup copy to the server's <code>/data/backups</code> folder (last 20 versions per file), in addition to any manual export above.</p>
        </div>
      `);

      document.getElementById('restore-btn').onclick = async () => {
        const fileInput = document.getElementById('restore-file');
        const file = fileInput.files[0];
        if (!file) return UI.toast('Choose a backup file first.', 'error');
        const ok = await UI.confirmModal({ title: 'Restore backup?', message: 'This overwrites ALL current farm data with the contents of the selected file. This cannot be undone.', confirmLabel: 'Restore & Overwrite' });
        if (!ok) return;
        try {
          const text = await file.text();
          const bundle = JSON.parse(text);
          await Api.importJson(bundle);
          UI.toast('Backup restored.');
          location.hash = '#/dashboard';
        } catch (e) { UI.toast('Restore failed: ' + e.message, 'error'); }
      };
    });
  }

  // ================= ACCOUNT (change username/password) =================
  async function accountView() {
    await withLoading(async () => {
      const [account, settings] = await Promise.all([Api.getAccount(), Api.getSettings()]);
      const modules = getModules(settings);
      setHtml(`
        <div class="page-header"><div><h1><i class="ti ti-user"></i> Account</h1><p class="subtitle">Signed in as <strong>${UI.esc(account.username)}</strong></p></div></div>

        <div class="card" style="max-width:440px">
          <h3 style="margin-top:0">Farm Details</h3>
          <p style="color:var(--text-dim);font-size:0.87rem;margin-top:0">Shown automatically on printed reports and animal records — handy for anything you hand to a vet, buyer, or inspector.</p>
          <form id="farm-details-form" class="form-grid" style="grid-template-columns:1fr">
            <div class="field"><label>Farm Name</label><input name="farmName" value="${UI.esc(settings.farmName)}"></div>
            <div class="field"><label>Farm Address</label><textarea name="farmAddress" placeholder="e.g. Hillside Farm&#10;Nether Wallop&#10;Hampshire&#10;SO20 8EX">${UI.esc(settings.farmAddress)}</textarea></div>
            <div class="field"><label>Holding Number (CPH)</label><input name="holdingNumber" placeholder="e.g. 12/345/6789" value="${UI.esc(settings.holdingNumber)}"></div>
            ${modules.sheep ? `<div class="field"><label>Flock Number</label><input name="flockNumber" placeholder="e.g. UK123456" value="${UI.esc(settings.flockNumber)}"></div>` : ''}
            ${(modules.cows || modules.sucklers) ? `<div class="field"><label>Herd Number</label><input name="herdNumber" placeholder="e.g. UK123456/001" value="${UI.esc(settings.herdNumber)}"></div>` : ''}
          </form>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn btn-primary" id="save-farm-details"><i class="ti ti-device-floppy"></i> Save Farm Details</button>
          </div>
        </div>

        <div class="card" style="max-width:440px">
          <h3 style="margin-top:0">Farm Modules</h3>
          <p style="color:var(--text-dim);font-size:0.87rem;margin-top:0">Hide sections you don't need — this only affects what's shown in the app, no records are deleted.</p>
          <form id="modules-form" class="form-grid" style="grid-template-columns:1fr">
            <label style="display:flex;align-items:center;gap:8px;font-weight:400">
              <input type="checkbox" name="sheep" ${modules.sheep ? 'checked' : ''} style="width:auto"> ${Icons.sheep} Sheep
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-weight:400">
              <input type="checkbox" name="cows" ${modules.cows ? 'checked' : ''} style="width:auto"> ${Icons.cow} Dairy cows / cattle
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-weight:400">
              <input type="checkbox" name="sucklers" ${modules.sucklers ? 'checked' : ''} style="width:auto"> ${Icons.cow} Suckler cows / beef cattle
            </label>
          </form>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn btn-primary" id="save-modules"><i class="ti ti-device-floppy"></i> Save Modules</button>
          </div>
        </div>

        <div class="card" style="max-width:440px">
          <h3 style="margin-top:0">Change Username / Password</h3>
          <form id="account-form" class="form-grid" style="grid-template-columns:1fr">
            <div class="field"><label>Current Password *</label><input name="currentPassword" type="password" required autocomplete="current-password"></div>
            <div class="field"><label>New Username (leave blank to keep current)</label><input name="newUsername" type="text" autocomplete="username" placeholder="${UI.esc(account.username)}"></div>
            <div class="field"><label>New Password (leave blank to keep current)</label><input name="newPassword" type="password" minlength="8" autocomplete="new-password"></div>
            <div class="field"><label>Confirm New Password</label><input name="confirmNewPassword" type="password" minlength="8" autocomplete="new-password"></div>
          </form>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn btn-primary" id="save-account"><i class="ti ti-device-floppy"></i> Save Changes</button>
          </div>
        </div>
      `);

      document.getElementById('save-farm-details').onclick = async () => {
        const fd = new FormData(document.getElementById('farm-details-form'));
        const details = Object.fromEntries(fd.entries());
        try {
          await Api.updateSettings(details);
          UI.toast('Farm details saved.');
        } catch (e) { UI.toast(e.message, 'error'); }
      };

      document.getElementById('save-modules').onclick = async () => {
        const fd = new FormData(document.getElementById('modules-form'));
        const newModules = { sheep: fd.get('sheep') === 'on', cows: fd.get('cows') === 'on', sucklers: fd.get('sucklers') === 'on' };
        if (!newModules.sheep && !newModules.cows && !newModules.sucklers) {
          return UI.toast('Select at least one — sheep, dairy cows, or suckler cows.', 'error');
        }
        try {
          await Api.updateSettings({ modules: newModules });
          UI.toast('Modules updated.');
          location.hash = '#/dashboard';
        } catch (e) { UI.toast(e.message, 'error'); }
      };

      document.getElementById('save-account').onclick = async () => {
        const form = document.getElementById('account-form');
        if (!form.reportValidity()) return;
        const fd = new FormData(form);
        const data = Object.fromEntries(fd.entries());
        if (data.newPassword && data.newPassword !== data.confirmNewPassword) {
          return UI.toast('New password and confirmation do not match.', 'error');
        }
        try {
          const result = await Api.updateAccount(data);
          UI.toast('Account updated.');
          form.reset();
          accountView();
        } catch (e) { UI.toast(e.message, 'error'); }
      };
    });
  }

  // ================= BULK TREATMENT =================
  async function bulkTreatment() {
    await withLoading(async () => {
      const animals = (await Api.listAnimals({})).filter(a => a.status !== 'archived');
      const selected = new Set();
      let filtered = animals;

      setHtml(`
        <div class="page-header">
          <div><h1><i class="ti ti-vaccine"></i> Bulk Add Treatment</h1><p class="subtitle">Record the same treatment for several animals at once — e.g. worming the whole flock in one visit</p></div>
          <a class="btn" href="#/dashboard"><i class="ti ti-arrow-left"></i> Back</a>
        </div>

        <div class="card">
          <h3 style="margin-top:0">1. Select Animals</h3>
          <form id="bt-filters" class="form-grid" style="grid-template-columns:repeat(5,1fr)">
            <div class="field"><label>Species</label>
              <select name="species"><option value="">All</option><option value="sheep">Sheep</option><option value="cow">Cow</option><option value="sucklercow">Suckler Cow</option></select>
            </div>
            <div class="field"><label>Sex</label>
              <select name="sex"><option value="">All</option><option value="female">Female</option><option value="male">Male</option><option value="wether">Wether</option></select>
            </div>
            <div class="field"><label>Breed</label><input name="breed" placeholder="e.g. Suffolk"></div>
            <div class="field"><label>Group / Mob</label><input name="group" placeholder="e.g. Triplet-bearing ewes"></div>
            <div class="field"><label>Status</label>
              <select name="status"><option value="">All (except archived)</option><option value="active">Active</option><option value="milking">Milking</option><option value="dry">Dry</option><option value="rearing">Rearing</option></select>
            </div>
          </form>
          <div class="btn-row" style="margin:12px 0">
            <button class="btn btn-sm" id="bt-select-all">Select All Shown</button>
            <button class="btn btn-sm" id="bt-select-none">Clear Selection</button>
            <span id="bt-count" style="align-self:center;color:var(--text-dim);font-size:0.87rem"></span>
          </div>
          <div class="table-wrap" style="max-height:380px;overflow-y:auto;border:1px solid var(--border);border-radius:8px">
            <table>
              <thead><tr><th style="width:36px"></th><th>Tag</th><th>Name</th><th>Species</th><th>Sex</th><th>Breed</th><th>Group</th><th>Status</th></tr></thead>
              <tbody id="bt-animal-rows"></tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <h3 style="margin-top:0">2. Treatment Details</h3>
          <form id="bt-form" class="form-grid">
            <div class="field"><label>Treatment Date *</label><input name="treatmentDate" type="date" required value="${todayStr()}"></div>
            <div class="field"><label>Medicine Name *</label><input name="medicineName" required></div>
            <div class="field"><label>Dose Administered</label><input name="dose"></div>
            <div class="field"><label>Route of Administration</label><input name="route"></div>
            <div class="field"><label>Withdrawal Period (days)</label><input name="withdrawalPeriod" type="number"></div>
            <div class="field"><label>Milk Withdrawal (days)</label><input name="milkWithdrawalPeriod" type="number"></div>
            <div class="field"><label>Meat Withdrawal (days)</label><input name="meatWithdrawalPeriod" type="number"></div>
            <div class="field"><label>Repeat Reminder (days, optional)</label><input name="repeatIntervalDays" type="number" placeholder="e.g. 365 for annual"></div>
            <div class="field full"><label>Reason for Treatment</label><input name="reason"></div>
            <div class="field full"><label>Notes</label><textarea name="notes"></textarea></div>
          </form>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn btn-primary" id="bt-submit"><i class="ti ti-device-floppy"></i> Record Treatment for Selected Animals</button>
          </div>
        </div>
      `);

      function updateCount() {
        document.getElementById('bt-count').textContent = `${selected.size} animal(s) selected`;
      }

      function renderRows() {
        const fd = new FormData(document.getElementById('bt-filters'));
        const species = fd.get('species');
        const sex = fd.get('sex');
        const breed = (fd.get('breed') || '').trim().toLowerCase();
        const group = (fd.get('group') || '').trim().toLowerCase();
        const status = fd.get('status');

        filtered = animals.filter(a => {
          if (species && a.species !== species) return false;
          if (sex && a.sex !== sex) return false;
          if (breed && !(a.breed || '').toLowerCase().includes(breed)) return false;
          if (group && !(a.group || '').toLowerCase().includes(group)) return false;
          if (status && a.status !== status) return false;
          return true;
        });

        const tbody = document.getElementById('bt-animal-rows');
        tbody.innerHTML = filtered.length ? filtered.map(a => `
          <tr>
            <td><input type="checkbox" data-id="${a.id}" ${selected.has(a.id) ? 'checked' : ''}></td>
            <td>${UI.esc(a.tagNumber)}</td>
            <td>${UI.esc(a.name || '—')}</td>
            <td>${a.species}</td>
            <td>${a.sex}</td>
            <td>${UI.esc(a.breed || '')}</td>
            <td>${UI.esc(a.group || '—')}</td>
            <td>${UI.badge(a.status)}</td>
          </tr>
        `).join('') : `<tr><td colspan="8" style="text-align:center;color:var(--text-dim);padding:20px">No animals match these filters.</td></tr>`;

        tbody.querySelectorAll('input[type=checkbox]').forEach(cb => {
          cb.addEventListener('change', () => {
            if (cb.checked) selected.add(cb.dataset.id); else selected.delete(cb.dataset.id);
            updateCount();
          });
        });
        updateCount();
      }

      document.getElementById('bt-filters').addEventListener('input', renderRows);
      document.getElementById('bt-filters').addEventListener('change', renderRows);
      document.getElementById('bt-select-all').onclick = (e) => { e.preventDefault(); filtered.forEach(a => selected.add(a.id)); renderRows(); };
      document.getElementById('bt-select-none').onclick = (e) => { e.preventDefault(); selected.clear(); renderRows(); };

      renderRows();

      document.getElementById('bt-submit').onclick = async () => {
        const form = document.getElementById('bt-form');
        if (!form.reportValidity()) return;
        if (selected.size === 0) return UI.toast('Select at least one animal first.', 'error');

        const base = Object.fromEntries(new FormData(form).entries());
        const ok = await UI.confirmModal({
          title: `Record "${base.medicineName}" for ${selected.size} animal(s)?`,
          message: 'This adds a separate treatment record (with its own withdrawal dates) to each selected animal.',
          confirmLabel: 'Record Treatment',
          danger: false
        });
        if (!ok) return;

        const submitBtn = document.getElementById('bt-submit');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Saving…';

        let success = 0, failed = 0;
        for (const id of selected) {
          const animal = animals.find(a => a.id === id);
          try {
            await Api.create('medicine', { ...base, animalId: id, species: animal.species });
            success++;
          } catch (e) {
            failed++;
          }
        }

        UI.toast(`Treatment recorded for ${success} animal(s)${failed ? `, ${failed} failed` : ''}.`, failed ? 'error' : 'success');
        location.hash = '#/dashboard';
      };
    });
  }

  // ================= SCAN (EID / tag reader) =================
  // Works with any USB or Bluetooth EID/tag reader that behaves as a
  // keyboard (the near-universal standard for these devices) — it just
  // needs a focused text field to type into and sends Enter when done.
  async function scanView(initialCode) {
    await withLoading(async () => {
      setHtml(`
        <div class="page-header">
          <div><h1><i class="ti ti-antenna"></i> Scan EID / Tag</h1><p class="subtitle">Works with any USB or Bluetooth EID reader that types into a text field — scan, and the page does the rest</p></div>
          <a class="btn" href="#/dashboard"><i class="ti ti-arrow-left"></i> Back</a>
        </div>

        <div class="card">
          <div class="field full">
            <label for="scan-input">Scan or type an EID / tag number, then press Enter</label>
            <input id="scan-input" type="text" autocomplete="off" style="font-size:1.3rem;padding:14px" placeholder="Ready to scan…">
          </div>
        </div>

        <div id="scan-result"></div>

        <div class="card" id="scan-log-card" style="display:none">
          <h3 style="margin-top:0">Scanned This Session</h3>
          <div id="scan-log"></div>
        </div>
      `);

      const input = document.getElementById('scan-input');
      const resultEl = document.getElementById('scan-result');
      const logCard = document.getElementById('scan-log-card');
      const logEl = document.getElementById('scan-log');
      const seen = [];

      input.focus();

      input.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        const code = input.value.trim();
        if (code) lookup(code);
      });

      async function lookup(code) {
        resultEl.innerHTML = `<div class="card"><div class="empty-state">Looking up "${UI.esc(code)}"…</div></div>`;
        let matches = [];
        try {
          matches = await Api.listAnimals({ q: code });
        } catch (e) {
          resultEl.innerHTML = `<div class="card"><div class="empty-state">Lookup failed: ${UI.esc(e.message)}</div></div>`;
          input.value = ''; input.focus();
          return;
        }

        const exact = matches.find(a => a.eidNumber === code) || matches.find(a => a.tagNumber === code);
        if (exact) {
          await showFound(exact, code);
        } else if (matches.length === 1) {
          await showFound(matches[0], code);
        } else if (matches.length > 1) {
          showAmbiguous(matches, code);
        } else {
          showNotFound(code);
        }
        input.value = '';
        input.focus();
      }

      async function showFound(animal, code) {
        let withdrawalHtml = '';
        try {
          const medicine = (await Api.list('medicine')).filter(m => m.animalId === animal.id);
          const t = todayStr();
          const active = medicine.filter(m =>
            (m.withdrawalEndDate && m.withdrawalEndDate >= t) ||
            (m.milkWithdrawalEndDate && m.milkWithdrawalEndDate >= t) ||
            (m.meatWithdrawalEndDate && m.meatWithdrawalEndDate >= t)
          );
          if (active.length) {
            withdrawalHtml = `<div class="alert warning" style="margin-top:10px"><i class="ti ti-alert-triangle"></i> Under withdrawal: ${active.map(m => UI.esc(m.medicineName)).join(', ')}</div>`;
          }
        } catch (e) { /* non-fatal — still show the animal even if this check fails */ }

        resultEl.innerHTML = `
          <div class="card">
            <h3 style="margin-top:0">${UI.esc(animalDisplay(animal))} ${UI.badge(animal.status)}</h3>
            <p>Tag ${UI.esc(animal.tagNumber)}${animal.eidNumber ? ` · EID ${UI.esc(animal.eidNumber)}` : ''} · ${UI.esc(animal.breed || 'Unknown breed')} · ${animal.sex}${animal.group ? ` · Group: ${UI.esc(animal.group)}` : ''}</p>
            ${withdrawalHtml}
            <div class="btn-row" style="margin-top:12px">
              <a class="btn btn-primary" href="#/${routeFor(animal.species)}/${animal.id}">View Full Profile</a>
            </div>
          </div>
        `;
        seen.unshift({ animal, code, at: new Date() });
        renderLog();
      }

      function showAmbiguous(matches, code) {
        resultEl.innerHTML = `
          <div class="card">
            <h3 style="margin-top:0">Multiple matches for "${UI.esc(code)}"</h3>
            <div class="link-list">
              ${matches.slice(0, 10).map(a => `<a href="#/${routeFor(a.species)}/${a.id}">${UI.esc(animalDisplay(a))} — ${UI.esc(a.tagNumber)}${a.eidNumber ? ' · EID ' + UI.esc(a.eidNumber) : ''}</a>`).join('')}
            </div>
          </div>
        `;
      }

      function showNotFound(code) {
        resultEl.innerHTML = `
          <div class="card">
            <h3 style="margin-top:0">No animal found for "${UI.esc(code)}"</h3>
            <p class="subtitle">Add it as a new animal with this EID pre-filled:</p>
            <div class="btn-row">
              <a class="btn btn-primary" href="#/sheep/new?eid=${encodeURIComponent(code)}">${Icons.sheep} Add as New Sheep</a>
              <a class="btn btn-primary" href="#/cows/new?eid=${encodeURIComponent(code)}">${Icons.cow} Add as New Cow</a>
              <a class="btn btn-primary" href="#/sucklers/new?eid=${encodeURIComponent(code)}">${Icons.cow} Add as New Suckler Cow</a>
            </div>
          </div>
        `;
      }

      function renderLog() {
        if (!seen.length) { logCard.style.display = 'none'; return; }
        logCard.style.display = '';
        logEl.innerHTML = UI.table([
          { label: 'Time', key: 'at', render: r => r.at.toLocaleTimeString() },
          { label: 'Scanned', key: 'code' },
          { label: 'Matched', key: 'animal', render: r => `<a href="#/${routeFor(r.animal.species)}/${r.animal.id}">${UI.esc(animalDisplay(r.animal))}</a>` },
          { label: 'Status', key: 'status', render: r => UI.badge(r.animal.status) }
        ], seen.slice(0, 25));
      }

      if (initialCode) {
        input.value = initialCode;
        lookup(initialCode);
      }
    });
  }

  // ================= FEED (inventory, purchases, usage) =================
  async function feedView(initialTab) {
    await withLoading(async () => {
      const [products, purchases, usage, summary, animals] = await Promise.all([
        Api.list('feedproducts'),
        Api.list('feedpurchases'),
        Api.list('feedusage'),
        Api.feedSummary(),
        Api.listAnimals({})
      ]);

      let currentTab = initialTab || 'inventory';
      const productMap = Object.fromEntries(products.map(p => [p.id, p]));
      const animalMap = Object.fromEntries(animals.map(a => [a.id, a]));

      setHtml(`
        <div class="page-header">
          <div><h1><i class="ti ti-package"></i> Feed</h1><p class="subtitle">Feed inventory, purchases, and usage</p></div>
        </div>
        <div class="tabs" id="feed-tabs">
          <button class="tab-btn" data-tab="inventory">Inventory</button>
          <button class="tab-btn" data-tab="purchases">Purchases</button>
          <button class="tab-btn" data-tab="usage">Usage</button>
        </div>
        <div id="feed-tab-content"></div>
      `);

      document.querySelectorAll('#feed-tabs .tab-btn').forEach(btn => {
        btn.onclick = () => { currentTab = btn.dataset.tab; renderTab(); };
      });

      function renderTab() {
        document.querySelectorAll('#feed-tabs .tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === currentTab));
        const el = document.getElementById('feed-tab-content');
        if (currentTab === 'inventory') return renderInventory(el);
        if (currentTab === 'purchases') return renderPurchases(el);
        if (currentTab === 'usage') return renderUsage(el);
      }

      function renderInventory(el) {
        el.innerHTML = `
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px"><button class="btn btn-primary" id="add-product"><i class="ti ti-plus"></i> Add Feed Product</button></div>
            ${UI.table([
              { label: 'Product', key: 'name' },
              { label: 'Unit', key: 'unit' },
              { label: 'Current Stock', key: 'currentStock' },
              { label: 'Purchased', key: 'purchasedQty' },
              { label: 'Used', key: 'usedQty' },
              { label: 'Avg Cost/Unit', key: 'avgUnitCost', render: r => `£${Number(r.avgUnitCost).toFixed(2)}` },
              { label: 'Total Spend', key: 'purchasedCost', render: r => `£${Number(r.purchasedCost).toFixed(2)}` }
            ], summary, { emptyText: 'No feed products yet — add one to get started.' })}
          </div>
        `;
        el.querySelector('#add-product').onclick = async () => {
          const data = await UI.formModal({
            title: 'Add Feed Product', submitLabel: 'Save',
            fields: [
              { name: 'name', label: 'Product Name', full: true, required: true, placeholder: 'e.g. Rolled Barley' },
              { name: 'unit', label: 'Unit', type: 'select', required: true, options: [
                { value: 'kg', label: 'kg' }, { value: 'tonne', label: 'tonne' }, { value: 'bag', label: 'bag' },
                { value: 'bale', label: 'bale' }, { value: 'litre', label: 'litre' }
              ] },
              { name: 'notes', label: 'Notes', type: 'textarea', full: true }
            ]
          });
          if (!data) return;
          await Api.create('feedproducts', data);
          UI.toast('Feed product added.');
          feedView('inventory');
        };
      }

      function renderPurchases(el) {
        el.innerHTML = `
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px">
              <button class="btn btn-primary" id="add-purchase"><i class="ti ti-plus"></i> Log Purchase</button>
              <a class="btn" href="${Api.exportCsvUrl('feedpurchases')}" target="_blank"><i class="ti ti-download"></i> Export CSV</a>
            </div>
            ${UI.table([
              { label: 'Date', key: 'date', render: r => UI.fmtDate(r.date) },
              { label: 'Product', key: 'productId', render: r => UI.esc((productMap[r.productId] || {}).name || 'Unknown') },
              { label: 'Quantity', key: 'quantity', render: r => `${r.quantity} ${(productMap[r.productId] || {}).unit || ''}`.trim() },
              { label: 'Total Cost', key: 'totalCost', render: r => `£${Number(r.totalCost || 0).toFixed(2)}` },
              { label: 'Supplier', key: 'supplier' },
              { label: 'Notes', key: 'notes', wrap: true },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm btn-danger" data-del-purchase="${r.id}">Del</button>` }
            ], purchases.slice().sort((a, b) => new Date(b.date) - new Date(a.date)), { emptyText: 'No purchases logged yet.' })}
          </div>
        `;
        if (!products.length) {
          el.querySelector('#add-purchase').onclick = () => UI.toast('Add a feed product first.', 'error');
        } else {
          el.querySelector('#add-purchase').onclick = async () => {
            const data = await UI.formModal({
              title: 'Log Feed Purchase', submitLabel: 'Save',
              fields: [
                { name: 'productId', label: 'Product', type: 'select', full: true, required: true, options: products.map(p => ({ value: p.id, label: `${p.name} (${p.unit})` })) },
                { name: 'date', label: 'Date', type: 'date', required: true, value: todayStr() },
                { name: 'quantity', label: 'Quantity', type: 'number', step: '0.01', required: true },
                { name: 'totalCost', label: 'Total Cost (£)', type: 'number', step: '0.01', required: true },
                { name: 'supplier', label: 'Supplier (optional)' },
                { name: 'notes', label: 'Notes', type: 'textarea', full: true }
              ]
            });
            if (!data) return;
            await Api.create('feedpurchases', data);
            UI.toast('Purchase logged.');
            feedView('purchases');
          };
        }
        el.querySelectorAll('[data-del-purchase]').forEach(btn => btn.onclick = async () => {
          const ok = await UI.confirmModal({ title: 'Delete this purchase?', message: 'This cannot be undone.', confirmLabel: 'Delete' });
          if (!ok) return;
          await Api.remove('feedpurchases', btn.dataset.delPurchase);
          UI.toast('Deleted.');
          feedView('purchases');
        });
      }

      function renderUsage(el) {
        el.innerHTML = `
          <div class="card">
            <div class="btn-row" style="margin-bottom:12px">
              <button class="btn btn-primary" id="add-usage"><i class="ti ti-plus"></i> Log Usage</button>
              <a class="btn" href="#/feed/bulk-usage"><i class="ti ti-users"></i> Log Batch Feeding</a>
              <a class="btn" href="${Api.exportCsvUrl('feedusage')}" target="_blank"><i class="ti ti-download"></i> Export CSV</a>
            </div>
            <p style="color:var(--text-dim);font-size:0.87rem">Usage logged against a specific animal (individually or as part of a batch) counts directly toward that animal's feed cost and profit/loss. General/group usage (no animal selected) is tracked here for farm-wide totals only — see Reports → Feed Cost Summary.</p>
            ${UI.table([
              { label: 'Date', key: 'date', render: r => UI.fmtDate(r.date) },
              { label: 'Product', key: 'productId', render: r => UI.esc((productMap[r.productId] || {}).name || 'Unknown') },
              { label: 'Quantity', key: 'quantity', render: r => `${r.quantity} ${(productMap[r.productId] || {}).unit || ''}`.trim() },
              { label: 'Animal', key: 'animalId', render: r => r.animalId && animalMap[r.animalId] ? `<a href="#/${routeFor(animalMap[r.animalId].species)}/${r.animalId}">${UI.esc(animalDisplay(animalMap[r.animalId]))}</a>` : '<span style="color:var(--text-dim)">General / group</span>' },
              { label: 'Notes', key: 'notes', wrap: true },
              { label: '', key: 'id', render: r => `<button class="btn btn-sm btn-danger" data-del-usage="${r.id}">Del</button>` }
            ], usage.slice().sort((a, b) => new Date(b.date) - new Date(a.date)), { emptyText: 'No usage logged yet.' })}
          </div>
        `;
        if (!products.length) {
          el.querySelector('#add-usage').onclick = () => UI.toast('Add a feed product first.', 'error');
        } else {
          el.querySelector('#add-usage').onclick = async () => {
            const animalOptions = [{ value: '', label: 'General / group (not a specific animal)' }].concat(
              animals.filter(a => a.status !== 'archived').map(a => ({ value: a.id, label: `${animalDisplay(a)} (${a.tagNumber}) — ${a.species}` }))
            );
            const data = await UI.formModal({
              title: 'Log Feed Usage', submitLabel: 'Save',
              fields: [
                { name: 'productId', label: 'Product', type: 'select', full: true, required: true, options: products.map(p => ({ value: p.id, label: `${p.name} (${p.unit})` })) },
                { name: 'date', label: 'Date', type: 'date', required: true, value: todayStr() },
                { name: 'quantity', label: 'Quantity', type: 'number', step: '0.01', required: true },
                { name: 'animalId', label: 'Animal (optional)', type: 'select', full: true, options: animalOptions },
                { name: 'notes', label: 'Notes', type: 'textarea', full: true }
              ]
            });
            if (!data) return;
            if (!data.animalId) delete data.animalId;
            await Api.create('feedusage', data);
            UI.toast('Usage logged.');
            feedView('usage');
          };
        }
        el.querySelectorAll('[data-del-usage]').forEach(btn => btn.onclick = async () => {
          const ok = await UI.confirmModal({ title: 'Delete this usage entry?', message: 'This cannot be undone.', confirmLabel: 'Delete' });
          if (!ok) return;
          await Api.remove('feedusage', btn.dataset.delUsage);
          UI.toast('Deleted.');
          feedView('usage');
        });
      }

      renderTab();
    });
  }

  // ================= BULK FEED USAGE =================
  // Log one feeding event across several animals at once — mirrors
  // bulkTreatment's filter/select UI. The total quantity (and so the
  // cost) is split evenly across whichever animals are selected, and one
  // precisely-attributed feedusage record is created per animal — unlike
  // the untracked "General / group" option, each animal here keeps its
  // own accurate share for profit/loss purposes.
  async function bulkFeedUsage() {
    await withLoading(async () => {
      const [allAnimals, products] = await Promise.all([
        Api.listAnimals({}),
        Api.list('feedproducts')
      ]);
      const animals = allAnimals.filter(a => a.status !== 'archived');

      if (!products.length) {
        setHtml(`
          <div class="page-header">
            <div><h1><i class="ti ti-users"></i> Log Batch Feeding</h1></div>
            <a class="btn" href="#/feed"><i class="ti ti-arrow-left"></i> Back to Feed</a>
          </div>
          ${UI.emptyState('Add a feed product first.', '<a class="btn btn-primary" href="#/feed">Go to Feed</a>')}
        `);
        return;
      }

      const selected = new Set();
      let filtered = animals;

      setHtml(`
        <div class="page-header">
          <div><h1><i class="ti ti-users"></i> Log Batch Feeding</h1><p class="subtitle">Record one feeding event across several animals at once — the quantity and cost are split evenly among whichever animals you select</p></div>
          <a class="btn" href="#/feed"><i class="ti ti-arrow-left"></i> Back to Feed</a>
        </div>

        <div class="card">
          <h3 style="margin-top:0">1. Select Animals</h3>
          <form id="bf-filters" class="form-grid" style="grid-template-columns:repeat(5,1fr)">
            <div class="field"><label>Species</label>
              <select name="species"><option value="">All</option><option value="sheep">Sheep</option><option value="cow">Cow</option><option value="sucklercow">Suckler Cow</option></select>
            </div>
            <div class="field"><label>Sex</label>
              <select name="sex"><option value="">All</option><option value="female">Female</option><option value="male">Male</option><option value="wether">Wether</option></select>
            </div>
            <div class="field"><label>Breed</label><input name="breed" placeholder="e.g. Suffolk"></div>
            <div class="field"><label>Group / Mob</label><input name="group" placeholder="e.g. Triplet-bearing ewes"></div>
            <div class="field"><label>Status</label>
              <select name="status"><option value="">All (except archived)</option><option value="active">Active</option><option value="milking">Milking</option><option value="dry">Dry</option><option value="rearing">Rearing</option></select>
            </div>
          </form>
          <div class="btn-row" style="margin:12px 0">
            <button class="btn btn-sm" id="bf-select-all">Select All Shown</button>
            <button class="btn btn-sm" id="bf-select-none">Clear Selection</button>
            <span id="bf-count" style="align-self:center;color:var(--text-dim);font-size:0.87rem"></span>
          </div>
          <div class="table-wrap" style="max-height:380px;overflow-y:auto;border:1px solid var(--border);border-radius:8px">
            <table>
              <thead><tr><th style="width:36px"></th><th>Tag</th><th>Name</th><th>Species</th><th>Sex</th><th>Breed</th><th>Group</th><th>Status</th></tr></thead>
              <tbody id="bf-animal-rows"></tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <h3 style="margin-top:0">2. Feeding Details</h3>
          <form id="bf-form" class="form-grid">
            <div class="field"><label>Product *</label>
              <select name="productId" required>${products.map(p => `<option value="${p.id}">${UI.esc(p.name)} (${UI.esc(p.unit)})</option>`).join('')}</select>
            </div>
            <div class="field"><label>Date *</label><input name="date" type="date" required value="${todayStr()}"></div>
            <div class="field"><label>Total Quantity Fed *</label><input name="totalQuantity" type="number" step="0.01" min="0.01" required placeholder="e.g. 50"></div>
            <div class="field"><label>Split</label><div style="padding-top:8px;color:var(--text-dim);font-size:0.87rem" id="bf-split-preview">Select animals to see the per-head split</div></div>
            <div class="field full"><label>Notes</label><textarea name="notes"></textarea></div>
          </form>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn btn-primary" id="bf-submit"><i class="ti ti-plus"></i> Log Feeding for Selected Animals</button>
          </div>
        </div>
      `);

      function updateSplitPreview() {
        const qty = parseFloat(document.querySelector('#bf-form [name="totalQuantity"]').value);
        const product = products.find(p => p.id === document.querySelector('#bf-form [name="productId"]').value);
        const preview = document.getElementById('bf-split-preview');
        if (selected.size > 0 && qty > 0) {
          const per = qty / selected.size;
          preview.textContent = `${per.toFixed(2)} ${product ? product.unit : ''} per animal (${selected.size} animals)`;
        } else {
          preview.textContent = 'Select animals and a quantity to see the per-head split';
        }
      }

      function updateCount() {
        document.getElementById('bf-count').textContent = `${selected.size} animal(s) selected`;
        updateSplitPreview();
      }

      function renderRows() {
        const fd = new FormData(document.getElementById('bf-filters'));
        const species = fd.get('species');
        const sex = fd.get('sex');
        const breed = (fd.get('breed') || '').trim().toLowerCase();
        const group = (fd.get('group') || '').trim().toLowerCase();
        const status = fd.get('status');

        filtered = animals.filter(a => {
          if (species && a.species !== species) return false;
          if (sex && a.sex !== sex) return false;
          if (breed && !(a.breed || '').toLowerCase().includes(breed)) return false;
          if (group && !(a.group || '').toLowerCase().includes(group)) return false;
          if (status && a.status !== status) return false;
          return true;
        });

        const tbody = document.getElementById('bf-animal-rows');
        tbody.innerHTML = filtered.length ? filtered.map(a => `
          <tr>
            <td><input type="checkbox" data-id="${a.id}" ${selected.has(a.id) ? 'checked' : ''}></td>
            <td>${UI.esc(a.tagNumber)}</td>
            <td>${UI.esc(a.name || '—')}</td>
            <td>${a.species}</td>
            <td>${a.sex}</td>
            <td>${UI.esc(a.breed || '')}</td>
            <td>${UI.esc(a.group || '—')}</td>
            <td>${UI.badge(a.status)}</td>
          </tr>
        `).join('') : `<tr><td colspan="8" style="text-align:center;color:var(--text-dim);padding:20px">No animals match these filters.</td></tr>`;

        tbody.querySelectorAll('input[type=checkbox]').forEach(cb => {
          cb.addEventListener('change', () => {
            if (cb.checked) selected.add(cb.dataset.id); else selected.delete(cb.dataset.id);
            updateCount();
          });
        });
        updateCount();
      }

      document.getElementById('bf-filters').addEventListener('input', renderRows);
      document.getElementById('bf-filters').addEventListener('change', renderRows);
      document.getElementById('bf-select-all').onclick = (e) => { e.preventDefault(); filtered.forEach(a => selected.add(a.id)); renderRows(); };
      document.getElementById('bf-select-none').onclick = (e) => { e.preventDefault(); selected.clear(); renderRows(); };
      document.querySelector('#bf-form [name="totalQuantity"]').addEventListener('input', updateSplitPreview);
      document.querySelector('#bf-form [name="productId"]').addEventListener('change', updateSplitPreview);

      renderRows();

      document.getElementById('bf-submit').onclick = async () => {
        const form = document.getElementById('bf-form');
        if (!form.reportValidity()) return;
        if (selected.size === 0) return UI.toast('Select at least one animal first.', 'error');

        const fd = new FormData(form);
        const productId = fd.get('productId');
        const date = fd.get('date');
        const totalQuantity = parseFloat(fd.get('totalQuantity'));
        const notes = (fd.get('notes') || '').trim();
        if (!totalQuantity || totalQuantity <= 0) return UI.toast('Enter a valid total quantity.', 'error');

        const perHeadQty = Math.round((totalQuantity / selected.size) * 100) / 100;
        const product = products.find(p => p.id === productId);
        const unit = product ? product.unit : '';

        const ok = await UI.confirmModal({
          title: `Log this feeding for ${selected.size} animal(s)?`,
          message: `${totalQuantity} ${unit} of ${product ? product.name : 'feed'} split evenly — ${perHeadQty} ${unit} each.`,
          confirmLabel: 'Log Feeding',
          danger: false
        });
        if (!ok) return;

        const submitBtn = document.getElementById('bf-submit');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Saving…';

        const batchNote = `Batch feeding, split across ${selected.size} animals${notes ? ' — ' + notes : ''}`;
        let success = 0, failed = 0;
        for (const animalId of selected) {
          try {
            await Api.create('feedusage', { productId, date, quantity: perHeadQty, animalId, notes: batchNote });
            success++;
          } catch (e) {
            failed++;
          }
        }

        UI.toast(`Feeding logged for ${success} animal(s)${failed ? `, ${failed} failed` : ''}.`, failed ? 'error' : 'success');
        location.hash = '#/feed';
      };
    });
  }

  // ================= BULK MOVEMENT =================
  // Log one movement event (purchase, sale, death, slaughter, show, etc.)
  // across several animals at once — same filter/select UI as Bulk
  // Treatment and Bulk Feed Usage. Price can be entered either as a flat
  // amount applied to every animal, or as a batch total split evenly.
  async function bulkMovement() {
    await withLoading(async () => {
      const allAnimals = await Api.listAnimals({});
      const animals = allAnimals.filter(a => a.status !== 'archived');
      const selected = new Set();
      let filtered = animals;

      setHtml(`
        <div class="page-header">
          <div><h1><i class="ti ti-truck"></i> Batch Movement</h1><p class="subtitle">Record one movement event — purchase, sale, death, slaughter, show, etc. — across several animals at once</p></div>
          <a class="btn" href="#/dashboard"><i class="ti ti-arrow-left"></i> Back</a>
        </div>

        <div class="card">
          <h3 style="margin-top:0">1. Select Animals</h3>
          <form id="bm-filters" class="form-grid" style="grid-template-columns:repeat(5,1fr)">
            <div class="field"><label>Species</label>
              <select name="species"><option value="">All</option><option value="sheep">Sheep</option><option value="cow">Cow</option><option value="sucklercow">Suckler Cow</option></select>
            </div>
            <div class="field"><label>Sex</label>
              <select name="sex"><option value="">All</option><option value="female">Female</option><option value="male">Male</option><option value="wether">Wether</option></select>
            </div>
            <div class="field"><label>Breed</label><input name="breed" placeholder="e.g. Suffolk"></div>
            <div class="field"><label>Group / Mob</label><input name="group" placeholder="e.g. Draft lambs"></div>
            <div class="field"><label>Status</label>
              <select name="status"><option value="">All (except archived)</option><option value="active">Active</option><option value="milking">Milking</option><option value="dry">Dry</option><option value="rearing">Rearing</option></select>
            </div>
          </form>
          <div class="btn-row" style="margin:12px 0">
            <button class="btn btn-sm" id="bm-select-all">Select All Shown</button>
            <button class="btn btn-sm" id="bm-select-none">Clear Selection</button>
            <span id="bm-count" style="align-self:center;color:var(--text-dim);font-size:0.87rem"></span>
          </div>
          <div class="table-wrap" style="max-height:380px;overflow-y:auto;border:1px solid var(--border);border-radius:8px">
            <table>
              <thead><tr><th style="width:36px"></th><th>Tag</th><th>Name</th><th>Species</th><th>Sex</th><th>Breed</th><th>Group</th><th>Status</th></tr></thead>
              <tbody id="bm-animal-rows"></tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <h3 style="margin-top:0">2. Movement Details</h3>
          <form id="bm-form" class="form-grid">
            <div class="field"><label>Direction *</label>
              <select name="direction" required>
                <option value="off">Off the farm (leaving)</option>
                <option value="on">Onto the farm (arriving)</option>
              </select>
            </div>
            <div class="field"><label>Date *</label><input name="date" type="date" required value="${todayStr()}"></div>
            <div class="field"><label>Reason *</label>
              <select name="reason" required>
                <option value="Sale">Sale</option>
                <option value="Purchase">Purchase</option>
                <option value="Death">Death (on farm / collected)</option>
                <option value="Slaughter/Abattoir">Slaughter / Abattoir</option>
                <option value="Show/Exhibition">Show / Exhibition</option>
                <option value="Return">Return to farm</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div class="field"><label>Farm / Market / Abattoir Name</label><input name="location"></div>
            <div class="field"><label>Holding Number / Reference (optional)</label><input name="locationReference"></div>
            <div class="field"><label>Transported By (optional)</label><input name="transportedBy"></div>
            <div class="field"><label>Price Type</label>
              <select id="bm-price-type">
                <option value="each">Same price for each animal</option>
                <option value="total">Total for the batch (split evenly)</option>
              </select>
            </div>
            <div class="field"><label id="bm-price-label">Price per Animal (£, optional)</label><input id="bm-price-input" type="number" step="0.01" min="0" placeholder="e.g. 85"></div>
            <div class="field"><label>Split Preview</label><div style="padding-top:8px;color:var(--text-dim);font-size:0.87rem" id="bm-split-preview">Select animals to see the total</div></div>
            <div class="field full"><label>Notes</label><textarea name="notes"></textarea></div>
          </form>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn btn-primary" id="bm-submit"><i class="ti ti-plus"></i> Log Movement for Selected Animals</button>
          </div>
        </div>
      `);

      function updateSplitPreview() {
        const priceType = document.getElementById('bm-price-type').value;
        const priceVal = parseFloat(document.getElementById('bm-price-input').value);
        const preview = document.getElementById('bm-split-preview');
        if (selected.size === 0 || !priceVal || priceVal <= 0) {
          preview.textContent = priceType === 'total' ? 'Select animals and a total to see the per-head price' : 'Select animals to see the batch total';
          return;
        }
        if (priceType === 'total') {
          const per = priceVal / selected.size;
          preview.textContent = `£${per.toFixed(2)} per animal (${selected.size} animals)`;
        } else {
          const total = priceVal * selected.size;
          preview.textContent = `£${total.toFixed(2)} total (${selected.size} animals × £${priceVal.toFixed(2)})`;
        }
      }

      function updateCount() {
        document.getElementById('bm-count').textContent = `${selected.size} animal(s) selected`;
        updateSplitPreview();
      }

      function renderRows() {
        const fd = new FormData(document.getElementById('bm-filters'));
        const species = fd.get('species');
        const sex = fd.get('sex');
        const breed = (fd.get('breed') || '').trim().toLowerCase();
        const group = (fd.get('group') || '').trim().toLowerCase();
        const status = fd.get('status');

        filtered = animals.filter(a => {
          if (species && a.species !== species) return false;
          if (sex && a.sex !== sex) return false;
          if (breed && !(a.breed || '').toLowerCase().includes(breed)) return false;
          if (group && !(a.group || '').toLowerCase().includes(group)) return false;
          if (status && a.status !== status) return false;
          return true;
        });

        const tbody = document.getElementById('bm-animal-rows');
        tbody.innerHTML = filtered.length ? filtered.map(a => `
          <tr>
            <td><input type="checkbox" data-id="${a.id}" ${selected.has(a.id) ? 'checked' : ''}></td>
            <td>${UI.esc(a.tagNumber)}</td>
            <td>${UI.esc(a.name || '—')}</td>
            <td>${a.species}</td>
            <td>${a.sex}</td>
            <td>${UI.esc(a.breed || '')}</td>
            <td>${UI.esc(a.group || '—')}</td>
            <td>${UI.badge(a.status)}</td>
          </tr>
        `).join('') : `<tr><td colspan="8" style="text-align:center;color:var(--text-dim);padding:20px">No animals match these filters.</td></tr>`;

        tbody.querySelectorAll('input[type=checkbox]').forEach(cb => {
          cb.addEventListener('change', () => {
            if (cb.checked) selected.add(cb.dataset.id); else selected.delete(cb.dataset.id);
            updateCount();
          });
        });
        updateCount();
      }

      document.getElementById('bm-filters').addEventListener('input', renderRows);
      document.getElementById('bm-filters').addEventListener('change', renderRows);
      document.getElementById('bm-select-all').onclick = (e) => { e.preventDefault(); filtered.forEach(a => selected.add(a.id)); renderRows(); };
      document.getElementById('bm-select-none').onclick = (e) => { e.preventDefault(); selected.clear(); renderRows(); };
      document.getElementById('bm-price-input').addEventListener('input', updateSplitPreview);
      document.getElementById('bm-price-type').addEventListener('change', () => {
        const priceType = document.getElementById('bm-price-type').value;
        document.getElementById('bm-price-label').textContent = priceType === 'total' ? 'Total Price for Batch (£, optional)' : 'Price per Animal (£, optional)';
        updateSplitPreview();
      });

      renderRows();

      document.getElementById('bm-submit').onclick = async () => {
        const form = document.getElementById('bm-form');
        if (!form.reportValidity()) return;
        if (selected.size === 0) return UI.toast('Select at least one animal first.', 'error');

        const fd = new FormData(form);
        const direction = fd.get('direction');
        const date = fd.get('date');
        const reason = fd.get('reason');
        const loc = fd.get('location') || '';
        const locationReference = fd.get('locationReference') || '';
        const transportedBy = fd.get('transportedBy') || '';
        const notes = (fd.get('notes') || '').trim();
        const priceType = document.getElementById('bm-price-type').value;
        const priceRaw = parseFloat(document.getElementById('bm-price-input').value);

        let perHeadPrice = null;
        if (!isNaN(priceRaw) && priceRaw > 0) {
          perHeadPrice = priceType === 'total' ? Math.round((priceRaw / selected.size) * 100) / 100 : priceRaw;
        }

        const directionLabel = direction === 'on' ? 'arriving' : 'leaving';
        const confirmMsg = perHeadPrice !== null
          ? `${selected.size} animal(s), ${directionLabel} — ${reason}. £${perHeadPrice.toFixed(2)} each${priceType === 'total' ? ` (from a total of £${priceRaw.toFixed(2)})` : ''}.`
          : `${selected.size} animal(s), ${directionLabel} — ${reason}. No price recorded.`;

        const ok = await UI.confirmModal({
          title: `Log this movement for ${selected.size} animal(s)?`,
          message: confirmMsg,
          confirmLabel: 'Log Movement',
          danger: false
        });
        if (!ok) return;

        const submitBtn = document.getElementById('bm-submit');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Saving…';

        const batchNote = notes ? `${notes} (batch of ${selected.size})` : `Batch movement of ${selected.size} animals`;
        let success = 0, failed = 0;
        for (const animalId of selected) {
          const animal = animals.find(a => a.id === animalId);
          try {
            await Api.create('movements', {
              direction, date, reason, location: loc, locationReference, transportedBy,
              price: perHeadPrice !== null ? perHeadPrice : '',
              notes: batchNote,
              animalId, species: animal.species
            });
            success++;
          } catch (e) {
            failed++;
          }
        }

        UI.toast(`Movement logged for ${success} animal(s)${failed ? `, ${failed} failed` : ''}.`, failed ? 'error' : 'success');

        // Offer to update status for every successfully-moved animal in one
        // go, rather than asking once per animal.
        if (direction === 'off') {
          const suggested = MOVEMENT_STATUS_SUGGESTIONS[reason];
          if (suggested) {
            const confirmStatus = await UI.confirmModal({
              title: 'Update animal status?',
              message: `Also mark all ${selected.size} animal(s) as "${suggested}"?`,
              confirmLabel: `Mark as ${suggested}`,
              danger: false
            });
            if (confirmStatus) {
              for (const animalId of selected) {
                const animal = animals.find(a => a.id === animalId);
                if (animal.status !== suggested) {
                  try { await Api.updateAnimal(animalId, { status: suggested }); } catch (e) { /* continue */ }
                }
              }
              UI.toast('Statuses updated.');
            }
          }
        }

        dashboard();
      };
    });
  }

  // ================= GROUPS / MOBS SUMMARY =================
  async function groupsView() {
    await withLoading(async () => {
      const [settings, animals] = await Promise.all([Api.getSettings(), Api.listAnimals({})]);
      const modules = getModules(settings);
      const active = animals.filter(a => a.status !== 'archived');

      const grouped = {}; // groupName -> { sheep: n, cow: n, sucklercow: n }
      let ungroupedCount = 0;
      active.forEach(a => {
        const g = (a.group || '').trim();
        if (!g) { ungroupedCount++; return; }
        if (!grouped[g]) grouped[g] = { sheep: 0, cow: 0, sucklercow: 0 };
        grouped[g][a.species] = (grouped[g][a.species] || 0) + 1;
      });

      const groupNames = Object.keys(grouped).sort((a, b) => a.localeCompare(b));
      const rows = [];
      groupNames.forEach(name => {
        const counts = grouped[name];
        if (modules.sheep && counts.sheep) rows.push({ name, species: 'sheep', count: counts.sheep });
        if (modules.cows && counts.cow) rows.push({ name, species: 'cow', count: counts.cow });
        if (modules.sucklers && counts.sucklercow) rows.push({ name, species: 'sucklercow', count: counts.sucklercow });
      });

      setHtml(`
        <div class="page-header">
          <div><h1><i class="ti ti-users"></i> Groups / Mobs</h1><p class="subtitle">${groupNames.length} group(s) in use${ungroupedCount ? ` · ${ungroupedCount} animal(s) with no group assigned` : ''}</p></div>
        </div>
        <div class="card">
          ${UI.table([
            { label: 'Group', key: 'name' },
            { label: 'Species', key: 'species', render: r => speciesLabel(r.species) },
            { label: 'Count', key: 'count' },
            { label: '', key: 'view', render: r => `<a class="btn btn-sm" href="#/${routeFor(r.species)}?group=${encodeURIComponent(r.name)}">View</a>` }
          ], rows, { emptyText: "No groups assigned yet — add a Group / Mob when adding or editing an animal to get started." })}
        </div>
      `);
    });
  }

  return {
    dashboard, animalList, animalForm, animalProfile, milkView, reportsView, dataView, accountView, bulkTreatment, scanView, feedView, bulkFeedUsage, groupsView, bulkMovement,
    _internal: { sexOptions, SHEEP_STATUSES, COW_STATUSES, animalDisplay, todayStr, animalPickerOptions, withLoading, setHtml, rootEl }
  };
})();
