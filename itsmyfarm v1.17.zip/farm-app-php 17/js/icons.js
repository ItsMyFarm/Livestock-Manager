// icons.js — front-facing sheep/cow "face" icons, hand-drawn to match the
// stroke weight and rounded style of the Tabler icon set (`ti ti-*`) used
// everywhere else in the app. Plain inline SVG so they inherit currentColor
// (works in the sidebar's active/hover states and dark mode) the same way
// a font icon would, without needing a custom icon font. Mirrors
// lib/icons.php — keep both in sync if you tweak the artwork.
const Icons = {
  sheep: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="icon-face" aria-hidden="true">'
    + '<path d="M6.5 13.5 C5.2 11.5 5.2 8.7 7.2 7.6 C8 6 9.6 6 10.2 7.6 C10.8 6.4 13.2 6.4 13.8 7.6 C14.4 6 16 6 16.8 7.6 C18.8 8.7 18.8 11.5 17.5 13.5 C17.5 16.5 15 19 12 19 C9 19 6.5 16.5 6.5 13.5 Z"/>'
    + '<ellipse cx="5.3" cy="14.2" rx="1" ry="1.6" transform="rotate(25 5.3 14.2)"/>'
    + '<ellipse cx="18.7" cy="14.2" rx="1" ry="1.6" transform="rotate(-25 18.7 14.2)"/>'
    + '<circle cx="10" cy="13.6" r="0.55" fill="currentColor" stroke="none"/>'
    + '<circle cx="14" cy="13.6" r="0.55" fill="currentColor" stroke="none"/>'
    + '<path d="M10.2 16.6 Q12 17.4 13.8 16.6"/>'
    + '</svg>',
  cow: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="icon-face" aria-hidden="true">'
    + '<path d="M7.3 7.6 Q5.6 5.4 6.6 3.4"/>'
    + '<path d="M16.7 7.6 Q18.4 5.4 17.4 3.4"/>'
    + '<rect x="5.3" y="7.3" width="13.4" height="11.4" rx="4.2" ry="4.2"/>'
    + '<ellipse cx="4" cy="11.3" rx="1.4" ry="0.8" transform="rotate(20 4 11.3)"/>'
    + '<ellipse cx="20" cy="11.3" rx="1.4" ry="0.8" transform="rotate(-20 20 11.3)"/>'
    + '<circle cx="9.2" cy="12.25" r="0.55" fill="currentColor" stroke="none"/>'
    + '<circle cx="14.8" cy="12.25" r="0.55" fill="currentColor" stroke="none"/>'
    + '<rect x="7.8" y="15.8" width="8.4" height="5.2" rx="2.4" ry="2.4"/>'
    + '<circle cx="10.3" cy="18.35" r="0.5" fill="currentColor" stroke="none"/>'
    + '<circle cx="13.7" cy="18.35" r="0.5" fill="currentColor" stroke="none"/>'
    + '</svg>',
};
