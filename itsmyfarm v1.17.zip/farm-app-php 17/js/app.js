// app.js — hash router, navigation state, theme toggle, and global search.
(function () {
  const sideNav = document.getElementById('side-nav');
  const navToggle = document.getElementById('nav-toggle');
  const themeToggle = document.getElementById('theme-toggle');

  navToggle.addEventListener('click', () => sideNav.classList.toggle('open'));
  document.getElementById('main-content').addEventListener('click', () => sideNav.classList.remove('open'));

  // Mirrors Views' internal routeFor() — kept small and local since app.js
  // doesn't share Views' closure. Keep in sync if a species' route changes.
  const routeForSpecies = (species) => species === 'cow' ? 'cows' : species === 'sucklercow' ? 'sucklers' : 'sheep';

  // ---------- theme ----------
  async function initTheme() {
    let theme = localStorage.getItem('farm-theme');
    if (!theme) {
      try { const settings = await Api.getSettings(); theme = settings.theme || 'light'; } catch (e) { theme = 'light'; }
    }
    applyTheme(theme);
  }
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    themeToggle.innerHTML = theme === 'dark' ? '<i class="ti ti-sun"></i>' : '<i class="ti ti-moon"></i>';
    localStorage.setItem('farm-theme', theme);
  }
  themeToggle.addEventListener('click', async () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try { await Api.updateSettings({ theme: next }); } catch (e) {}
  });

  // ---------- logout ----------
  document.getElementById('logout-btn').addEventListener('click', async () => {
    try { await Api.logout(); } catch (e) {}
    window.location.href = Api.loginUrl();
  });

  // ---------- global search ----------
  const searchInput = document.getElementById('global-search-input');
  const searchResults = document.getElementById('global-search-results');
  let searchTimer = null;

  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimer);
    const q = searchInput.value.trim();
    if (!q) { searchResults.classList.add('hidden'); return; }
    searchTimer = setTimeout(async () => {
      try {
        const results = await Api.listAnimals({ q });
        searchInput.dataset.lastResults = JSON.stringify(results.slice(0, 12));
        if (!results.length) {
          searchResults.innerHTML = `<div style="padding:10px 12px;color:var(--text-dim)">No matches.</div>`;
        } else {
          searchResults.innerHTML = results.slice(0, 12).map(a => `
            <a href="#/${routeForSpecies(a.species)}/${a.id}">
              <span>${UI.esc(a.name || a.tagNumber)}</span>
              <span class="tag">${a.species} · ${UI.esc(a.tagNumber)}</span>
            </a>`).join('');
        }
        searchResults.classList.remove('hidden');
      } catch (e) { /* ignore */ }
    }, 220);
  });
  // EID/tag scanners act as keyboards and send Enter after the code — jump
  // straight to the animal instead of making the person click the result.
  searchInput.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    let results = [];
    try { results = JSON.parse(searchInput.dataset.lastResults || '[]'); } catch (err) {}
    if (results.length === 1) {
      const a = results[0];
      searchInput.value = '';
      searchResults.classList.add('hidden');
      location.hash = `#/${routeForSpecies(a.species)}/${a.id}`;
    } else if (results.length > 1) {
      searchResults.classList.remove('hidden');
    } else if (searchInput.value.trim()) {
      location.hash = `#/scan?code=${encodeURIComponent(searchInput.value.trim())}`;
      searchInput.value = '';
      searchResults.classList.add('hidden');
    }
  });
  searchResults.addEventListener('click', () => { searchResults.classList.add('hidden'); searchInput.value = ''; });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.global-search')) searchResults.classList.add('hidden');
  });

  // ---------- router ----------
  function setActiveNav(routeKey) {
    document.querySelectorAll('#side-nav a').forEach(a => a.classList.toggle('active', a.dataset.route === routeKey));
  }

  function parseHash() {
    const hash = location.hash.replace(/^#\/?/, '').split('?')[0];
    return hash.split('/').filter(Boolean);
  }

  function hashQuery() {
    return new URLSearchParams(location.hash.split('?')[1] || '');
  }

  function route() {
    const parts = parseHash();
    window.scrollTo(0, 0);

    if (!parts.length || parts[0] === 'dashboard') {
      setActiveNav('dashboard');
      return Views.dashboard();
    }
    if (parts[0] === 'scan') { setActiveNav('scan'); return Views.scanView(hashQuery().get('code') || ''); }
    if (parts[0] === 'sheep') {
      if (parts[1] === 'new') { setActiveNav('sheep-new'); return Views.animalForm('sheep', null, { eidNumber: hashQuery().get('eid') || '' }); }
      if (parts[1] && parts[2] === 'edit') { setActiveNav('sheep'); return Views.animalForm('sheep', parts[1]); }
      if (parts[1]) { setActiveNav('sheep'); return Views.animalProfile(parts[1], parts[2]); }
      setActiveNav('sheep'); return Views.animalList('sheep');
    }
    if (parts[0] === 'cows') {
      if (parts[1] === 'new') { setActiveNav('cows-new'); return Views.animalForm('cow', null, { eidNumber: hashQuery().get('eid') || '' }); }
      if (parts[1] && parts[2] === 'edit') { setActiveNav('cows'); return Views.animalForm('cow', parts[1]); }
      if (parts[1]) { setActiveNav('cows'); return Views.animalProfile(parts[1], parts[2]); }
      setActiveNav(hashQuery().get('status') === 'rearing' ? 'cows-rearing' : 'cows');
      return Views.animalList('cow');
    }
    if (parts[0] === 'sucklers') {
      if (parts[1] === 'new') { setActiveNav('sucklers-new'); return Views.animalForm('sucklercow', null, { eidNumber: hashQuery().get('eid') || '' }); }
      if (parts[1] && parts[2] === 'edit') { setActiveNav('sucklers'); return Views.animalForm('sucklercow', parts[1]); }
      if (parts[1]) { setActiveNav('sucklers'); return Views.animalProfile(parts[1], parts[2]); }
      setActiveNav(hashQuery().get('status') === 'rearing' ? 'sucklers-rearing' : 'sucklers');
      return Views.animalList('sucklercow');
    }
    if (parts[0] === 'milk') { setActiveNav('milk'); return Views.milkView(); }
    if (parts[0] === 'bulk-treatment') { setActiveNav('bulk-treatment'); return Views.bulkTreatment(); }
    if (parts[0] === 'groups') { setActiveNav('groups'); return Views.groupsView(); }
    if (parts[0] === 'bulk-movement') { setActiveNav('bulk-movement'); return Views.bulkMovement(); }
    if (parts[0] === 'feed') {
      if (parts[1] === 'bulk-usage') { setActiveNav('feed'); return Views.bulkFeedUsage(); }
      setActiveNav('feed'); return Views.feedView();
    }
    if (parts[0] === 'reports') { setActiveNav('reports'); return Views.reportsView(parts[1]); }
    if (parts[0] === 'data') { setActiveNav('data'); return Views.dataView(); }
    if (parts[0] === 'account') { setActiveNav('account'); return Views.accountView(); }

    setActiveNav('dashboard');
    return Views.dashboard();
  }

  window.addEventListener('hashchange', route);
  window.addEventListener('DOMContentLoaded', async () => {
    await initTheme();
    route();
  });
})();
