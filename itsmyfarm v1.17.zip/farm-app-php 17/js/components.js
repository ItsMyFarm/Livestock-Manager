// components.js — small reusable UI building blocks shared by every view.
const UI = (() => {

  function toast(message, type = 'success') {
    const el = document.createElement('div');
    el.className = `toast ${type === 'error' ? 'error' : ''}`;
    el.textContent = message;
    document.getElementById('toast-container').appendChild(el);
    setTimeout(() => el.remove(), 3200);
  }

  function confirmModal({ title = 'Are you sure?', message = '', confirmLabel = 'Confirm', danger = true }) {
    return new Promise((resolve) => {
      const root = document.getElementById('modal-root');
      root.innerHTML = `
        <div class="modal-backdrop">
          <div class="modal">
            <h3>${esc(title)}</h3>
            <p>${esc(message)}</p>
            <div class="btn-row" style="justify-content:flex-end">
              <button class="btn" id="modal-cancel">Cancel</button>
              <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" id="modal-confirm">${esc(confirmLabel)}</button>
            </div>
          </div>
        </div>`;
      root.querySelector('#modal-cancel').onclick = () => { root.innerHTML = ''; resolve(false); };
      root.querySelector('#modal-confirm').onclick = () => { root.innerHTML = ''; resolve(true); };
      root.querySelector('.modal-backdrop').addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-backdrop')) { root.innerHTML = ''; resolve(false); }
      });
    });
  }

  function esc(str) {
    if (str === undefined || str === null) return '';
    return String(str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function fmtDate(d) {
    if (!d) return '—';
    const dt = new Date(d);
    if (isNaN(dt.getTime())) return d;
    return dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  }

  function daysUntil(dateStr) {
    if (!dateStr) return null;
    const d = new Date(dateStr), t = new Date();
    t.setHours(0, 0, 0, 0);
    return Math.round((d - t) / 86400000);
  }

  function statCard(label, value, cls = '') {
    return `<div class="card stat-card ${cls}"><div class="value">${esc(value)}</div><div class="label">${esc(label)}</div></div>`;
  }

  function badge(status) {
    return `<span class="badge badge-${esc((status || '').toLowerCase())}">${esc(status || 'unknown')}</span>`;
  }

  function emptyState(text, actionHtml = '') {
    return `<div class="empty-state">${esc(text)}${actionHtml ? `<div style="margin-top:12px">${actionHtml}</div>` : ''}</div>`;
  }

  // --- simple dependency-free SVG line chart ---
  function lineChart({ points, width = 640, height = 200, yLabel = '', color = 'var(--green-500)' }) {
    if (!points.length) return emptyState('No data yet to chart.');
    const pad = { left: 42, right: 14, top: 14, bottom: 26 };
    const w = width - pad.left - pad.right;
    const h = height - pad.top - pad.bottom;
    const xs = points.map((_, i) => i);
    const ys = points.map(p => p.y);
    const minY = Math.min(0, ...ys);
    const maxY = Math.max(...ys, 1);
    const xScale = (i) => pad.left + (points.length <= 1 ? w / 2 : (i / (points.length - 1)) * w);
    const yScale = (v) => pad.top + h - ((v - minY) / (maxY - minY || 1)) * h;

    const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${xScale(i).toFixed(1)} ${yScale(p.y).toFixed(1)}`).join(' ');
    const gridLines = 4;
    let grid = '';
    for (let i = 0; i <= gridLines; i++) {
      const v = minY + ((maxY - minY) * i) / gridLines;
      const y = yScale(v);
      grid += `<line class="gridline" x1="${pad.left}" x2="${width - pad.right}" y1="${y}" y2="${y}" />`;
      grid += `<text x="4" y="${y + 3}">${v.toFixed(1)}</text>`;
    }
    // show at most 8 x labels to avoid clutter
    const labelEvery = Math.max(1, Math.ceil(points.length / 8));
    let xLabels = '';
    points.forEach((p, i) => {
      if (i % labelEvery === 0 || i === points.length - 1) {
        xLabels += `<text x="${xScale(i)}" y="${height - 6}" text-anchor="middle">${esc(p.x)}</text>`;
      }
    });

    return `<div class="chart-wrap"><svg class="chart" viewBox="0 0 ${width} ${height}" width="100%" height="${height}">
      ${grid}${xLabels}
      <path class="line" d="${path}" />
      ${points.map((p, i) => `<circle class="point" cx="${xScale(i)}" cy="${yScale(p.y)}" r="2.5"><title>${esc(p.x)}: ${esc(p.y)}</title></circle>`).join('')}
    </svg></div>`;
  }

  function barChart({ bars, width = 640, height = 200 }) {
    if (!bars.length) return emptyState('No data yet to chart.');
    const pad = { left: 42, right: 14, top: 14, bottom: 26 };
    const w = width - pad.left - pad.right;
    const h = height - pad.top - pad.bottom;
    const maxY = Math.max(...bars.map(b => b.y), 1);
    const bw = Math.max(4, (w / bars.length) * 0.7);
    const gap = w / bars.length;
    const yScale = (v) => pad.top + h - (v / maxY) * h;
    let grid = '';
    for (let i = 0; i <= 4; i++) {
      const v = (maxY * i) / 4;
      const y = yScale(v);
      grid += `<line class="gridline" x1="${pad.left}" x2="${width - pad.right}" y1="${y}" y2="${y}" />`;
      grid += `<text x="4" y="${y + 3}">${v.toFixed(1)}</text>`;
    }
    const labelEvery = Math.max(1, Math.ceil(bars.length / 8));
    let content = '';
    bars.forEach((b, i) => {
      const x = pad.left + i * gap + (gap - bw) / 2;
      const y = yScale(b.y);
      content += `<rect class="bar${b.alt ? ' alt' : ''}" x="${x}" y="${y}" width="${bw}" height="${(pad.top + h) - y}"><title>${esc(b.x)}: ${esc(b.y)}</title></rect>`;
      if (i % labelEvery === 0 || i === bars.length - 1) {
        content += `<text x="${x + bw / 2}" y="${height - 6}" text-anchor="middle">${esc(b.x)}</text>`;
      }
    });
    return `<div class="chart-wrap"><svg class="chart" viewBox="0 0 ${width} ${height}" width="100%" height="${height}">${grid}${content}</svg></div>`;
  }

  function table(columns, rows, { emptyText = 'No records yet.' } = {}) {
    if (!rows.length) return emptyState(emptyText);
    return `<div class="table-wrap"><table>
      <thead><tr>${columns.map(c => `<th>${esc(c.label)}</th>`).join('')}</tr></thead>
      <tbody>${rows.map(r => `<tr>${columns.map(c => `<td class="${c.wrap ? 'wrap' : ''}">${c.render ? c.render(r) : esc(r[c.key])}</td>`).join('')}</tr>`).join('')}</tbody>
    </table></div>`;
  }

  // Generic form-in-a-modal. fields: [{name,label,type,options,required,value,step,placeholder}]
  function formModal({ title, fields, submitLabel = 'Save' }) {
    return new Promise((resolve) => {
      const root = document.getElementById('modal-root');
      const fieldHtml = fields.map(f => {
        const val = f.value !== undefined && f.value !== null ? f.value : '';
        const req = f.required ? 'required' : '';
        if (f.type === 'select') {
          return `<div class="field ${f.full ? 'full' : ''}"><label>${esc(f.label)}</label>
            <select name="${f.name}" ${req}>
              ${(f.options || []).map(o => `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}
            </select></div>`;
        }
        if (f.type === 'textarea') {
          return `<div class="field full"><label>${esc(f.label)}</label><textarea name="${f.name}" ${req} placeholder="${esc(f.placeholder || '')}">${esc(val)}</textarea></div>`;
        }
        return `<div class="field ${f.full ? 'full' : ''}"><label>${esc(f.label)}</label>
          <input name="${f.name}" type="${f.type || 'text'}" ${req} value="${esc(val)}" ${f.step ? `step="${f.step}"` : ''} placeholder="${esc(f.placeholder || '')}">
          </div>`;
      }).join('');

      root.innerHTML = `
        <div class="modal-backdrop">
          <div class="modal" style="max-width:520px">
            <h3>${esc(title)}</h3>
            <form id="dynamic-form" class="form-grid">${fieldHtml}</form>
            <div class="btn-row" style="justify-content:flex-end;margin-top:14px">
              <button class="btn" id="modal-cancel-2">Cancel</button>
              <button class="btn btn-primary" id="modal-submit-2">${esc(submitLabel)}</button>
            </div>
          </div>
        </div>`;

      const close = (result) => { root.innerHTML = ''; resolve(result); };
      root.querySelector('#modal-cancel-2').onclick = () => close(null);
      root.querySelector('.modal-backdrop').addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-backdrop')) close(null);
      });
      root.querySelector('#modal-submit-2').onclick = () => {
        const form = root.querySelector('#dynamic-form');
        if (!form.reportValidity()) return;
        const data = {};
        fields.forEach(f => { data[f.name] = new FormData(form).get(f.name); });
        close(data);
      };
    });
  }

  return { toast, confirmModal, formModal, esc, fmtDate, daysUntil, statCard, badge, emptyState, lineChart, barChart, table };
})();
