// api.js — thin wrapper around fetch for every backend endpoint.
const Api = (() => {
  // Support running in a subfolder (e.g. https://example.com/farm/)
  // instead of at the root of a domain/subdomain. index.php/login.php/
  // setup.php each inject window.APP_BASE before this script loads.
  const BASE = (typeof window !== 'undefined' && window.APP_BASE) ? window.APP_BASE : '';

  async function req(method, url, body) {
    const opts = { method, headers: {} };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(BASE + url, opts);
    if (res.status === 401) {
      // session expired or not logged in — bounce to the login page
      window.location.href = BASE + '/login.php';
      throw new Error('Not authenticated');
    }
    if (!res.ok) {
      let msg = `Request failed (${res.status})`;
      try { const j = await res.json(); if (j.error) msg = j.error; } catch (e) {}
      throw new Error(msg);
    }
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) return res.json();
    return res.text();
  }

  const get = (url) => req('GET', url);
  const post = (url, body) => req('POST', url, body);
  const put = (url, body) => req('PUT', url, body);
  const del = (url) => req('DELETE', url);

  return {
    // animals
    listAnimals: (params = {}) => {
      const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([, v]) => v)));
      const s = qs.toString();
      return get(`/api/animals${s ? '?' + s : ''}`);
    },
    getAnimal: (id) => get(`/api/animals/${id}`),
    createAnimal: (data) => post('/api/animals', data),
    updateAnimal: (id, data) => put(`/api/animals/${id}`, data),
    archiveAnimal: (id) => post(`/api/animals/${id}/archive`),
    offspringOf: (id) => get(`/api/animals/${id}/offspring`),
    timelineOf: (id) => get(`/api/animals/${id}/timeline`),

    // sub-collections (generic)
    list: (name) => get(`/api/${name}`),
    create: (name, data) => post(`/api/${name}`, data),
    update: (name, id, data) => put(`/api/${name}/${id}`, data),
    remove: (name, id) => del(`/api/${name}/${id}`),

    // dashboard / alerts
    dashboard: () => get('/api/dashboard'),
    alerts: () => get('/api/alerts'),

    // milk
    milkSummaryForCow: (cowId) => get(`/api/milk/summary/${cowId}`),
    herdDaily: () => get('/api/milk/herd-daily'),

    // reports
    report: (name) => get(`/api/reports/${name}`),

    // settings
    getSettings: () => get('/api/settings'),
    updateSettings: (data) => put('/api/settings', data),

    // export/import
    exportCsvUrl: (name) => `${BASE}/api/export/csv/${name}`,
    exportJsonUrl: () => `${BASE}/api/export/json`,
    importJson: (bundle) => post('/api/import/json', bundle),

    // account / auth
    getAccount: () => get('/api/account'),
    updateAccount: (data) => post('/api/account', data),
    logout: () => post('/api/logout'),
    loginUrl: () => `${BASE}/login.php`,

    // feed inventory & cost
    feedSummary: () => get('/api/feed/summary'),
    animalFeedCost: (id) => get(`/api/animals/${id}/feed-cost`)
  };
})();
