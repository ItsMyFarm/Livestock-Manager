<?php
// lib/db.php — flat-file JSON "database" layer with real file locking.
// Unlike a single-threaded Node process, PHP under Apache/PHP-FPM can run
// several requests at once, so every read takes a shared lock and every
// write takes an exclusive lock to prevent two simultaneous saves from
// corrupting a file.

if (!defined('FARM_APP')) { http_response_code(403); exit('Forbidden'); }

define('DB_COLLECTIONS', ['animals', 'breeding', 'medicine', 'weights', 'milk', 'milktests', 'movements', 'feedproducts', 'feedpurchases', 'feedusage', 'settings']);

function db_data_dir() {
    if (defined('FARM_DATA_DIR')) return FARM_DATA_DIR;
    return __DIR__ . '/../data';
}

function db_backup_dir() {
    return db_data_dir() . '/backups';
}

function db_ensure_dirs() {
    $dataDir = db_data_dir();
    if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
    $backupDir = db_backup_dir();
    if (!is_dir($backupDir)) mkdir($backupDir, 0755, true);
}

function db_file_path($name) {
    return db_data_dir() . "/$name.json";
}

function db_ensure_file($name) {
    $fp = db_file_path($name);
    if (!file_exists($fp)) {
        db_ensure_dirs();
        $initial = ($name === 'settings') ? '{}' : '[]';
        file_put_contents($fp, $initial, LOCK_EX);
    }
}

// ---------- generic raw read/write (used for db collections AND for
// auth/session/lockout files, which live outside the DB_COLLECTIONS
// list on purpose so backups/import/export never touch credentials) ----------

function db_read_raw($path, $fallback) {
    if (!file_exists($path)) return $fallback;
    $fh = @fopen($path, 'r');
    if (!$fh) return $fallback;
    flock($fh, LOCK_SH);
    $raw = stream_get_contents($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    if ($raw === '' || $raw === false) return $fallback;
    $data = json_decode($raw, true);
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) return $fallback;
    return $data;
}

function db_write_raw($path, $data) {
    $dir = dirname($path);
    if (!is_dir($dir)) mkdir($dir, 0700, true);
    $fh = fopen($path, 'c+');
    if (!$fh) throw new Exception("Could not open $path for writing");
    flock($fh, LOCK_EX);
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
}

// ---------- collection read/write (animals.json, breeding.json, etc.) ----------

function db_read($name) {
    db_ensure_file($name);
    $fallback = ($name === 'settings') ? [] : [];
    return db_read_raw(db_file_path($name), $fallback);
}

// Lightweight rolling backup: copy the current file into data/backups/
// before every write, keeping the most recent 20 copies per collection.
function db_backup($name) {
    $fp = db_file_path($name);
    if (!file_exists($fp)) return;
    db_ensure_dirs();
    // PHP's date() has no real microsecond support (its 'u' format always
    // reads as 000000), so two backups in the same second would otherwise
    // collide and silently overwrite each other. A short random suffix
    // guarantees uniqueness regardless of timing.
    $stamp = date('Y-m-d\TH-i-s') . '-' . bin2hex(random_bytes(3));
    $dest = db_backup_dir() . "/{$name}.{$stamp}.json";
    @copy($fp, $dest);

    $files = glob(db_backup_dir() . "/{$name}.*.json");
    if ($files === false) return;
    sort($files);
    $maxBackups = 20;
    while (count($files) > $maxBackups) {
        $old = array_shift($files);
        @unlink($old);
    }
}

function db_write($name, $data) {
    db_ensure_dirs();
    db_backup($name);
    // settings.json is conceptually a key/value object; without this, an
    // empty settings array would encode as JSON `[]` instead of `{}`.
    $toStore = ($name === 'settings' && is_array($data)) ? (object) $data : $data;
    db_write_raw(db_file_path($name), $toStore);
    return $data;
}

function db_next_id($prefix) {
    return $prefix . '-' . dechex(time()) . '-' . bin2hex(random_bytes(4));
}
