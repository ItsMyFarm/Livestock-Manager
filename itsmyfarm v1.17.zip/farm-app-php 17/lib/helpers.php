<?php
// lib/helpers.php — all the computed/derived logic, ported line-for-line
// from the Node version's helpers.js so behaviour stays identical.

if (!defined('FARM_APP')) { http_response_code(403); exit('Forbidden'); }

function h_add_days($dateStr, $days) {
    if (!$dateStr || $days === null || $days === '') return null;
    $ts = strtotime($dateStr);
    if ($ts === false) return null;
    $result = strtotime('+' . intval($days) . ' days', $ts);
    if ($result === false) return null;
    return date('Y-m-d', $result);
}

function h_days_between($a, $b) {
    if (!$a || !$b) return null;
    $ta = strtotime($a);
    $tb = strtotime($b);
    if ($ta === false || $tb === false) return null;
    return (int) round(($tb - $ta) / 86400);
}

function h_today() {
    return date('Y-m-d');
}

// Cow and sucklercow share breeding/calving terminology and cattle sex
// labels — milk recording is the one thing that's dairy-('cow')-only.
// Mirrors isCattle() in js/views.js — keep both in sync.
function h_is_cattle($species) {
    return $species === 'cow' || $species === 'sucklercow';
}

function h_find_by_id($arr, $id) {
    if ($id === null) return null;
    foreach ($arr as $item) {
        if (($item['id'] ?? null) === $id) return $item;
    }
    return null;
}

// Reimplements JS Array.prototype.slice(begin, end) exactly, including its
// negative-index clamping rules — PHP's array_slice() clamps an
// out-of-range negative offset differently, which matters for the milk
// drop-detection window below.
function h_js_slice($arr, $begin, $end = null) {
    $len = count($arr);
    $b = $begin < 0 ? max($len + $begin, 0) : min($begin, $len);
    $e = ($end === null) ? $len : ($end < 0 ? max($len + $end, 0) : min($end, $len));
    if ($e < $b) $e = $b;
    return array_slice($arr, $b, $e - $b);
}

// ---------- medicine withdrawal ----------

function h_compute_withdrawal($record) {
    $r = $record;
    if (!empty($r['treatmentDate'])) {
        if (isset($r['withdrawalPeriod']) && $r['withdrawalPeriod'] !== '') {
            $r['withdrawalEndDate'] = h_add_days($r['treatmentDate'], $r['withdrawalPeriod']);
        }
        if (isset($r['milkWithdrawalPeriod']) && $r['milkWithdrawalPeriod'] !== '') {
            $r['milkWithdrawalEndDate'] = h_add_days($r['treatmentDate'], $r['milkWithdrawalPeriod']);
        }
        if (isset($r['meatWithdrawalPeriod']) && $r['meatWithdrawalPeriod'] !== '') {
            $r['meatWithdrawalEndDate'] = h_add_days($r['treatmentDate'], $r['meatWithdrawalPeriod']);
        }
        if (isset($r['repeatIntervalDays']) && $r['repeatIntervalDays'] !== '') {
            $r['nextDueDate'] = h_add_days($r['treatmentDate'], $r['repeatIntervalDays']);
        }
    }
    return $r;
}

function h_animals_under_withdrawal($medicine) {
    $t = h_today();
    $byAnimal = [];
    foreach ($medicine as $m) {
        $active = (!empty($m['withdrawalEndDate']) && $m['withdrawalEndDate'] >= $t)
            || (!empty($m['milkWithdrawalEndDate']) && $m['milkWithdrawalEndDate'] >= $t)
            || (!empty($m['meatWithdrawalEndDate']) && $m['meatWithdrawalEndDate'] >= $t);
        if ($active) {
            $aid = $m['animalId'] ?? null;
            if (!isset($byAnimal[$aid])) $byAnimal[$aid] = [];
            $byAnimal[$aid][] = $m;
        }
    }
    return $byAnimal;
}

// ---------- timeline ----------

function h_build_timeline($id, $animal, $data) {
    $events = [];

    $events[] = [
        'date' => $animal['dob'] ?? ($animal['createdAt'] ?? null),
        'type' => 'birth',
        'label' => 'Born',
        'detail' => $animal['breed'] ?? ''
    ];

    if (!empty($animal['motherId'])) {
        $mother = h_find_by_id($data['animals'], $animal['motherId']);
        $motherLabel = $mother ? (($mother['name'] ?: $mother['tagNumber'])) : $animal['motherId'];
        $detail = "Dam: $motherLabel";
        if (!empty($animal['fatherId'])) $detail .= ', Sire: ' . $animal['fatherId'];
        $events[] = [
            'date' => $animal['dob'] ?? ($animal['createdAt'] ?? null),
            'type' => 'parentage',
            'label' => 'Parentage recorded',
            'detail' => $detail
        ];
    }

    foreach ($data['breeding'] as $b) {
        if (($b['animalId'] ?? null) !== $id) continue;
        $method = $b['method'] ?? '';
        $sireInfo = !empty($b['sireInfo']) ? ('with ' . $b['sireInfo']) : '';
        $events[] = [
            'date' => $b['eventDate'] ?? null,
            'type' => 'breeding',
            'label' => 'Breeding event',
            'detail' => trim("$method $sireInfo")
        ];
        if (!empty($b['actualDate'])) {
            $events[] = [
                'date' => $b['actualDate'],
                'type' => 'birthing',
                'label' => h_is_cattle($animal['species'] ?? null) ? 'Calving' : 'Lambing',
                'detail' => $b['notes'] ?? ''
            ];
        } elseif (!empty($b['expectedDate'])) {
            $events[] = [
                'date' => $b['expectedDate'],
                'type' => 'expected-birthing',
                'label' => 'Expected ' . (h_is_cattle($animal['species'] ?? null) ? 'calving' : 'lambing'),
                'detail' => ''
            ];
        }
    }

    foreach ($data['medicine'] as $m) {
        if (($m['animalId'] ?? null) !== $id) continue;
        $detail = trim(($m['dose'] ?? '') . ' ' . ($m['route'] ?? '') . ' — ' . ($m['reason'] ?? ''));
        $events[] = [
            'date' => $m['treatmentDate'] ?? null,
            'type' => 'medicine',
            'label' => 'Treatment: ' . ($m['medicineName'] ?? ''),
            'detail' => $detail
        ];
    }

    foreach ($data['weights'] as $w) {
        if (($w['animalId'] ?? null) !== $id) continue;
        $events[] = [
            'date' => $w['date'] ?? null,
            'type' => 'weight',
            'label' => 'Weight recorded',
            'detail' => ($w['weight'] ?? '') . ' kg'
        ];
    }

    if (($animal['species'] ?? null) === 'cow') {
        foreach ($data['milk'] as $m) {
            if (($m['cowId'] ?? null) !== $id) continue;
            $events[] = [
                'date' => $m['date'] ?? null,
                'type' => 'milk',
                'label' => 'Milking (' . ($m['session'] ?? '') . ')',
                'detail' => ($m['litres'] ?? '') . ' L'
            ];
        }
        foreach ($data['milktests'] as $m) {
            if (($m['cowId'] ?? null) !== $id) continue;
            $bf = $m['butterfat'] ?? '-';
            $pr = $m['protein'] ?? '-';
            $scc = $m['scc'] ?? '-';
            $events[] = [
                'date' => $m['date'] ?? null,
                'type' => 'milktest',
                'label' => 'Milk test',
                'detail' => "Butterfat {$bf}%, Protein {$pr}%, SCC {$scc}"
            ];
        }
    }

    foreach ($data['animals'] as $o) {
        if (($o['motherId'] ?? null) === $id || ($o['fatherId'] ?? null) === $id) {
            $events[] = [
                'date' => $o['dob'] ?? ($o['createdAt'] ?? null),
                'type' => 'offspring',
                'label' => 'Offspring born',
                'detail' => ($o['name'] ?? '') ?: ($o['tagNumber'] ?? '')
            ];
        }
    }

    foreach (($data['movements'] ?? []) as $mv) {
        if (($mv['animalId'] ?? null) !== $id) continue;
        $label = (($mv['direction'] ?? '') === 'on') ? 'Moved onto farm' : 'Moved off farm';
        $detail = trim(($mv['reason'] ?? '') . (!empty($mv['location']) ? ' — ' . $mv['location'] : ''));
        $events[] = [
            'date' => $mv['date'] ?? null,
            'type' => 'movement',
            'label' => $label,
            'detail' => $detail
        ];
    }

    if (!empty($data['feedusage'])) {
        $feedProductsById = [];
        foreach (($data['feedproducts'] ?? []) as $fp) $feedProductsById[$fp['id']] = $fp;
        foreach ($data['feedusage'] as $u) {
            if (($u['animalId'] ?? null) !== $id) continue;
            $product = $feedProductsById[$u['productId'] ?? null] ?? null;
            $productName = $product ? ($product['name'] ?? 'Feed') : 'Feed';
            $unit = $product ? ($product['unit'] ?? '') : '';
            $events[] = [
                'date' => $u['date'] ?? null,
                'type' => 'feed',
                'label' => 'Fed: ' . $productName,
                'detail' => trim(($u['quantity'] ?? '') . ' ' . $unit)
            ];
        }
    }

    $events[] = [
        'date' => $animal['createdAt'] ?? null,
        'type' => 'status',
        'label' => 'Status: ' . ($animal['status'] ?? ''),
        'detail' => ''
    ];

    $events = array_values(array_filter($events, function ($e) { return !empty($e['date']); }));
    usort($events, function ($a, $b) { return strtotime($a['date']) <=> strtotime($b['date']); });

    return $events;
}

// ---------- milk ----------

function h_milk_summary_for_cow($milkRecords) {
    $byDate = [];
    foreach ($milkRecords as $m) {
        $d = $m['date'] ?? null;
        if ($d === null) continue;
        $byDate[$d] = ($byDate[$d] ?? 0) + floatval($m['litres'] ?? 0);
    }
    $dates = array_keys($byDate);
    sort($dates);

    $rolling = function ($n) use ($dates, $byDate) {
        $last = array_slice($dates, -$n);
        if (count($last) === 0) return 0;
        $sum = 0;
        foreach ($last as $d) $sum += $byDate[$d];
        return round(($sum / count($last)) * 100) / 100;
    };

    $history = [];
    foreach ($dates as $d) {
        $history[] = ['date' => $d, 'litres' => round($byDate[$d] * 100) / 100];
    }

    $dropAlert = false;
    if (count($dates) >= 8) {
        $recent7 = $rolling(7);
        $priorDates = h_js_slice($dates, -14, -7);
        if (count($priorDates) > 0) {
            $priorSum = 0;
            foreach ($priorDates as $d) $priorSum += $byDate[$d];
            $priorAvg = $priorSum / count($priorDates);
            if ($priorAvg > 0 && $recent7 < $priorAvg * 0.8) $dropAlert = true;
        }
    }

    $lactationAvg = 0;
    if (count($dates) > 0) {
        $sumAll = array_sum($byDate);
        $lactationAvg = round(($sumAll / count($dates)) * 100) / 100;
    }

    $today = h_today();
    return [
        'dailyTotals' => $history,
        'todayTotal' => $byDate[$today] ?? 0,
        'avg7' => $rolling(7),
        'avg30' => $rolling(30),
        'avgLactation' => $lactationAvg,
        'dropAlert' => $dropAlert
    ];
}

function h_herd_daily_totals($milk) {
    $byDate = [];
    foreach ($milk as $m) {
        $d = $m['date'] ?? null;
        if ($d === null) continue;
        $byDate[$d] = ($byDate[$d] ?? 0) + floatval($m['litres'] ?? 0);
    }
    $dates = array_keys($byDate);
    sort($dates);
    $result = [];
    foreach ($dates as $d) {
        $result[] = ['date' => $d, 'litres' => round($byDate[$d] * 100) / 100];
    }
    return $result;
}

// ---------- dashboard ----------

function h_build_dashboard($data) {
    $animals = $data['animals'];
    $breeding = $data['breeding'];
    $medicine = $data['medicine'];
    $milk = $data['milk'];

    $sheep = array_values(array_filter($animals, function ($a) {
        return ($a['species'] ?? null) === 'sheep' && ($a['status'] ?? null) !== 'archived';
    }));
    $cows = array_values(array_filter($animals, function ($a) {
        return ($a['species'] ?? null) === 'cow' && ($a['status'] ?? null) !== 'archived';
    }));
    $sucklers = array_values(array_filter($animals, function ($a) {
        return ($a['species'] ?? null) === 'sucklercow' && ($a['status'] ?? null) !== 'archived';
    }));

    $t = h_today();
    $in21 = h_add_days($t, 21);

    $ewes = array_values(array_filter($sheep, function ($a) { return ($a['sex'] ?? null) === 'female'; }));
    $lambs = array_values(array_filter($sheep, function ($a) use ($t) {
        if (empty($a['dob'])) return false;
        $d = h_days_between($a['dob'], $t);
        return $d !== null && $d <= 180;
    }));

    $pregnantEwes = array_values(array_filter($breeding, function ($b) use ($animals) {
        $animal = h_find_by_id($animals, $b['animalId'] ?? null);
        return $animal && ($animal['species'] ?? null) === 'sheep' && !empty($b['expectedDate']) && empty($b['actualDate']);
    }));

    $lambingsDueSoon = array_values(array_filter($breeding, function ($b) use ($animals, $t, $in21) {
        $animal = h_find_by_id($animals, $b['animalId'] ?? null);
        return $animal && ($animal['species'] ?? null) === 'sheep' && !empty($b['expectedDate']) && empty($b['actualDate'])
            && $b['expectedDate'] <= $in21 && $b['expectedDate'] >= $t;
    }));

    // Calvings-due, withdrawal, recent-treatments and recent-calvings follow
    // the same shape for both cattle species — cow (dairy) and sucklercow
    // (beef) — so this small closure builds that shared slice once and the
    // dairy-only fields (milking/dry/todaysMilk) are added on top for cows.
    $withdrawalMap = h_animals_under_withdrawal($medicine);
    $buildCattleSection = function ($species, $herd) use ($animals, $breeding, $medicine, $withdrawalMap, $t, $in21) {
        $calvingsDueSoon = array_values(array_filter($breeding, function ($b) use ($animals, $species, $t, $in21) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            return $animal && ($animal['species'] ?? null) === $species && !empty($b['expectedDate']) && empty($b['actualDate'])
                && $b['expectedDate'] <= $in21 && $b['expectedDate'] >= $t;
        }));

        $withdrawalCount = 0;
        foreach (array_keys($withdrawalMap) as $aid) {
            $a = h_find_by_id($animals, $aid);
            if ($a && ($a['species'] ?? null) === $species) $withdrawalCount++;
        }

        $med = array_values(array_filter($medicine, function ($m) use ($animals, $species) {
            $a = h_find_by_id($animals, $m['animalId'] ?? null);
            return $a && ($a['species'] ?? null) === $species;
        }));
        usort($med, function ($a, $b) { return strtotime($b['treatmentDate'] ?? '') <=> strtotime($a['treatmentDate'] ?? ''); });

        $calvingsWithActual = array_values(array_filter($breeding, function ($b) use ($animals, $species) {
            $a = h_find_by_id($animals, $b['animalId'] ?? null);
            return $a && ($a['species'] ?? null) === $species && !empty($b['actualDate']);
        }));
        usort($calvingsWithActual, function ($a, $b) { return strtotime($b['actualDate']) <=> strtotime($a['actualDate']); });

        return [
            'total' => count($herd),
            'rearing' => count(array_filter($herd, function ($a) { return ($a['status'] ?? null) === 'rearing'; })),
            'calvingsDueSoon' => $calvingsDueSoon,
            'underWithdrawal' => $withdrawalCount,
            'recentTreatments' => array_slice($med, 0, 5),
            'recentCalvings' => array_slice($calvingsWithActual, 0, 5)
        ];
    };

    $sheepWithdrawal = 0;
    foreach (array_keys($withdrawalMap) as $aid) {
        $a = h_find_by_id($animals, $aid);
        if ($a && ($a['species'] ?? null) === 'sheep') $sheepWithdrawal++;
    }

    $medSheep = array_values(array_filter($medicine, function ($m) use ($animals) {
        $a = h_find_by_id($animals, $m['animalId'] ?? null);
        return $a && ($a['species'] ?? null) === 'sheep';
    }));
    usort($medSheep, function ($a, $b) { return strtotime($b['treatmentDate'] ?? '') <=> strtotime($a['treatmentDate'] ?? ''); });

    $sheepWithDob = array_values(array_filter($sheep, function ($a) { return !empty($a['dob']); }));
    usort($sheepWithDob, function ($a, $b) { return strtotime($b['dob']) <=> strtotime($a['dob']); });

    $cowSection = $buildCattleSection('cow', $cows);
    $sucklerSection = $buildCattleSection('sucklercow', $sucklers);

    $todaysMilk = 0;
    foreach ($milk as $m) {
        if (($m['date'] ?? null) === $t) $todaysMilk += floatval($m['litres'] ?? 0);
    }

    return [
        'sheep' => [
            'total' => count($sheep),
            'totalEwes' => count($ewes),
            'totalLambs' => count($lambs),
            'pregnantEwes' => count($pregnantEwes),
            'lambingsDueSoon' => $lambingsDueSoon,
            'underWithdrawal' => $sheepWithdrawal,
            'recentTreatments' => array_slice($medSheep, 0, 5),
            'recentBirths' => array_slice($sheepWithDob, 0, 5)
        ],
        'cows' => array_merge($cowSection, [
            'milking' => count(array_filter($cows, function ($a) { return ($a['status'] ?? null) === 'milking'; })),
            'dry' => count(array_filter($cows, function ($a) { return ($a['status'] ?? null) === 'dry'; })),
            'todaysMilk' => round($todaysMilk * 100) / 100
        ]),
        'sucklers' => $sucklerSection
    ];
}

// ---------- alerts ----------

function h_build_alerts($data) {
    $animals = $data['animals'];
    $breeding = $data['breeding'];
    $medicine = $data['medicine'];
    $milk = $data['milk'];
    $milktests = $data['milktests'];

    $t = h_today();
    $in7 = h_add_days($t, 7);
    $in21 = h_add_days($t, 21);
    $alerts = [];

    foreach ($medicine as $m) {
        $fieldPairs = [
            ['withdrawalEndDate', 'general withdrawal'],
            ['milkWithdrawalEndDate', 'milk withdrawal'],
            ['meatWithdrawalEndDate', 'meat withdrawal']
        ];
        foreach ($fieldPairs as $fp) {
            $field = $fp[0];
            $label = $fp[1];
            if (!empty($m[$field])) {
                $val = $m[$field];
                $animal = h_find_by_id($animals, $m['animalId'] ?? null);
                $animalLabel = $animal ? ($animal['name'] ?: $animal['tagNumber']) : ($m['animalId'] ?? '');
                $medName = $m['medicineName'] ?? '';
                if ($val >= $t && $val <= $in7) {
                    $alerts[] = [
                        'type' => 'withdrawal-ending', 'severity' => 'warning', 'date' => $val,
                        'message' => "$label for $animalLabel ends $val ($medName)"
                    ];
                } elseif ($val >= $t) {
                    $alerts[] = [
                        'type' => 'withdrawal-active', 'severity' => 'info', 'date' => $val,
                        'message' => "$animalLabel under $label until $val ($medName)"
                    ];
                }
            }
        }
    }

    // Recurring treatment/vaccination reminders. Only the most recent
    // treatment of a given medicine name per animal matters here — an
    // older dose's "next due" is superseded the moment a newer one of the
    // same medicine is logged, so we find the latest per (animal, medicine)
    // pair before generating any alert.
    $latestByAnimalMedicine = [];
    foreach ($medicine as $m) {
        if (empty($m['repeatIntervalDays']) || empty($m['nextDueDate']) || empty($m['treatmentDate'])) continue;
        $animal = h_find_by_id($animals, $m['animalId'] ?? null);
        if (!$animal || in_array($animal['status'] ?? '', ['archived', 'deceased', 'sold'], true)) continue;
        $key = ($m['animalId'] ?? '') . '|' . strtolower($m['medicineName'] ?? '');
        if (!isset($latestByAnimalMedicine[$key]) || strtotime($m['treatmentDate']) > strtotime($latestByAnimalMedicine[$key]['treatmentDate'])) {
            $latestByAnimalMedicine[$key] = $m;
        }
    }
    foreach ($latestByAnimalMedicine as $m) {
        $animal = h_find_by_id($animals, $m['animalId'] ?? null);
        $animalLabel = $animal ? ($animal['name'] ?: $animal['tagNumber']) : ($m['animalId'] ?? '');
        $medName = $m['medicineName'] ?? '';
        if ($m['nextDueDate'] < $t) {
            $alerts[] = [
                'type' => 'vaccination-overdue', 'severity' => 'warning', 'date' => $m['nextDueDate'],
                'message' => "$animalLabel overdue for $medName (was due {$m['nextDueDate']})"
            ];
        } elseif ($m['nextDueDate'] <= $in21) {
            $alerts[] = [
                'type' => 'vaccination-due', 'severity' => 'info', 'date' => $m['nextDueDate'],
                'message' => "$animalLabel due for $medName again around {$m['nextDueDate']}"
            ];
        }
    }

    foreach ($breeding as $b) {
        if (!empty($b['expectedDate']) && empty($b['actualDate']) && $b['expectedDate'] >= $t && $b['expectedDate'] <= $in21) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            $isSheep = $animal && ($animal['species'] ?? null) === 'sheep';
            $animalLabel = $animal ? ($animal['name'] ?: $animal['tagNumber']) : ($b['animalId'] ?? '');
            $verb = $isSheep ? 'lamb' : 'calve';
            $alerts[] = [
                'type' => $isSheep ? 'lambing-due' : 'calving-due', 'severity' => 'info', 'date' => $b['expectedDate'],
                'message' => "$animalLabel expected to $verb {$b['expectedDate']}"
            ];
        }
        if (!empty($b['eventDate'])) {
            $daysSince = h_days_between($b['eventDate'], $t);
            if (empty($b['pregnancyCheckResult']) && empty($b['actualDate']) && $daysSince !== null && $daysSince >= 30 && $daysSince <= 60) {
                $animal = h_find_by_id($animals, $b['animalId'] ?? null);
                $animalLabel = $animal ? ($animal['name'] ?: $animal['tagNumber']) : ($b['animalId'] ?? '');
                $alerts[] = [
                    'type' => 'pregnancy-check-due', 'severity' => 'info', 'date' => $b['eventDate'],
                    'message' => "$animalLabel may be due a pregnancy check (bred $daysSince days ago)"
                ];
            }
        }
    }

    foreach ($milktests as $mt) {
        if (!empty($mt['scc']) && floatval($mt['scc']) > 200000) {
            $animal = h_find_by_id($animals, $mt['cowId'] ?? null);
            $animalLabel = $animal ? ($animal['name'] ?: $animal['tagNumber']) : ($mt['cowId'] ?? '');
            $sccVal = $mt['scc'];
            $alerts[] = [
                'type' => 'high-scc', 'severity' => 'warning', 'date' => $mt['date'] ?? $t,
                'message' => "High somatic cell count ($sccVal) for $animalLabel on {$mt['date']}"
            ];
        }
    }

    $cows = array_values(array_filter($animals, function ($a) {
        return ($a['species'] ?? null) === 'cow' && ($a['status'] ?? null) !== 'archived';
    }));
    foreach ($cows as $cow) {
        $records = array_values(array_filter($milk, function ($m) use ($cow) { return ($m['cowId'] ?? null) === $cow['id']; }));
        $summary = h_milk_summary_for_cow($records);
        if ($summary['dropAlert']) {
            $label = $cow['name'] ?: $cow['tagNumber'];
            $alerts[] = [
                'type' => 'milk-drop', 'severity' => 'warning', 'date' => $t,
                'message' => "Milk yield drop detected for $label"
            ];
        }
    }

    usort($alerts, function ($a, $b) { return strtotime($a['date']) <=> strtotime($b['date']); });
    return $alerts;
}

// ---------- reports ----------

function h_build_report($name, $data) {
    $animals = $data['animals'];
    $breeding = $data['breeding'];
    $medicine = $data['medicine'];
    $milk = $data['milk'];
    $milktests = $data['milktests'];
    $movements = $data['movements'] ?? [];
    $feedproducts = $data['feedproducts'] ?? [];
    $feedpurchases = $data['feedpurchases'] ?? [];
    $feedusage = $data['feedusage'] ?? [];

    $sheep = array_values(array_filter($animals, function ($a) { return ($a['species'] ?? null) === 'sheep'; }));
    $cows = array_values(array_filter($animals, function ($a) { return ($a['species'] ?? null) === 'cow'; }));
    $cattle = array_values(array_filter($animals, function ($a) { return h_is_cattle($a['species'] ?? null); }));

    if ($name === 'lambing-summary') {
        $rows = [];
        foreach ($breeding as $b) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            if (!$animal || ($animal['species'] ?? null) !== 'sheep' || empty($b['actualDate'])) continue;
            $lambCount = 0;
            foreach ($animals as $l) {
                if (($l['motherId'] ?? null) === ($b['animalId'] ?? null) && ($l['dob'] ?? null) === $b['actualDate']) $lambCount++;
            }
            $rows[] = [
                'ewe' => $animal['name'] ?: $animal['tagNumber'],
                'lambingDate' => $b['actualDate'],
                'lambCount' => $lambCount,
                'ram' => $b['sireInfo'] ?? '',
                'notes' => $b['notes'] ?? ''
            ];
        }
        return ['title' => 'Lambing Summary', 'rows' => $rows];
    }

    if ($name === 'ewe-productivity') {
        $ewes = array_values(array_filter($sheep, function ($a) { return ($a['sex'] ?? null) === 'female'; }));
        $rows = [];
        foreach ($ewes as $ewe) {
            $offspring = array_values(array_filter($animals, function ($a) use ($ewe) { return ($a['motherId'] ?? null) === $ewe['id']; }));
            $lambingDates = [];
            foreach ($offspring as $o) $lambingDates[$o['dob'] ?? ''] = true;
            $rows[] = [
                'ewe' => $ewe['name'] ?: $ewe['tagNumber'],
                'totalLambs' => count($offspring),
                'lambingEvents' => count($lambingDates)
            ];
        }
        return ['title' => 'Ewe Productivity', 'rows' => $rows];
    }

    if ($name === 'treatment-history') {
        $rows = [];
        foreach ($medicine as $m) {
            $animal = h_find_by_id($animals, $m['animalId'] ?? null);
            $rows[] = [
                'animal' => $animal ? ($animal['name'] ?: $animal['tagNumber']) : ($m['animalId'] ?? ''),
                'species' => $animal ? ($animal['species'] ?? '') : '',
                'date' => $m['treatmentDate'] ?? '',
                'medicine' => $m['medicineName'] ?? '',
                'dose' => $m['dose'] ?? '',
                'reason' => $m['reason'] ?? ''
            ];
        }
        usort($rows, function ($a, $b) { return strtotime($b['date']) <=> strtotime($a['date']); });
        return ['title' => 'Treatment History', 'rows' => $rows];
    }

    if ($name === 'mortality-report') {
        $rows = [];
        foreach ($animals as $a) {
            if (($a['status'] ?? null) === 'deceased') {
                $rows[] = [
                    'animal' => $a['name'] ?: $a['tagNumber'],
                    'species' => $a['species'] ?? '',
                    'dob' => $a['dob'] ?? '',
                    'notes' => $a['notes'] ?? ''
                ];
            }
        }
        return ['title' => 'Mortality Report', 'rows' => $rows];
    }

    if ($name === 'flock-inventory') {
        $rows = [];
        foreach ($sheep as $a) {
            if (($a['status'] ?? null) === 'archived') continue;
            $rows[] = [
                'tag' => $a['tagNumber'] ?? '', 'name' => $a['name'] ?? '', 'sex' => $a['sex'] ?? '',
                'breed' => $a['breed'] ?? '', 'group' => $a['group'] ?? '', 'dob' => $a['dob'] ?? '', 'status' => $a['status'] ?? ''
            ];
        }
        return ['title' => 'Flock Inventory', 'rows' => $rows];
    }

    if ($name === 'flock-performance-kpis') {
        // Grouped by lambing season (the year of the expected lambing date,
        // falling back to actual/tupping date if expected isn't set) so
        // multi-year history builds up naturally as seasons complete.
        $scanValues = ['empty' => 0, 'single' => 1, 'twin' => 2, 'triplet' => 3, 'quad' => 4];
        $seasons = [];
        foreach ($breeding as $b) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            if (!$animal || ($animal['species'] ?? null) !== 'sheep') continue;
            $seasonDate = $b['expectedDate'] ?: ($b['actualDate'] ?: ($b['eventDate'] ?? null));
            if (!$seasonDate || strlen($seasonDate) < 4) continue;
            $year = substr($seasonDate, 0, 4);
            if (!isset($seasons[$year])) {
                $seasons[$year] = [
                    'ewesTupped' => 0, 'ewesScanned' => 0, 'totalLambsScanned' => 0,
                    'emptyCount' => 0, 'ewesLambed' => 0, 'totalLambsBorn' => 0
                ];
            }
            $seasons[$year]['ewesTupped']++;

            $scanResult = $b['scanResult'] ?? '';
            if ($scanResult !== '' && isset($scanValues[$scanResult])) {
                $seasons[$year]['ewesScanned']++;
                $seasons[$year]['totalLambsScanned'] += $scanValues[$scanResult];
                if ($scanResult === 'empty') $seasons[$year]['emptyCount']++;
            }

            if (!empty($b['actualDate'])) {
                $seasons[$year]['ewesLambed']++;
                $lambCount = 0;
                foreach ($animals as $l) {
                    if (($l['motherId'] ?? null) === ($b['animalId'] ?? null) && ($l['dob'] ?? null) === $b['actualDate']) $lambCount++;
                }
                $seasons[$year]['totalLambsBorn'] += $lambCount;
            }
        }

        krsort($seasons);
        $rows = [];
        foreach ($seasons as $year => $s) {
            $rows[] = [
                'season' => $year,
                'ewesTupped' => $s['ewesTupped'],
                'ewesScanned' => $s['ewesScanned'],
                'scanningPercent' => $s['ewesScanned'] > 0 ? round($s['totalLambsScanned'] / $s['ewesScanned'] * 100) . '%' : '',
                'barrenPercent' => $s['ewesScanned'] > 0 ? round($s['emptyCount'] / $s['ewesScanned'] * 100) . '%' : '',
                'ewesLambed' => $s['ewesLambed'],
                'totalLambsBorn' => $s['totalLambsBorn'],
                'lambingPercent' => $s['ewesTupped'] > 0 ? round($s['totalLambsBorn'] / $s['ewesTupped'] * 100) . '%' : ''
            ];
        }
        return ['title' => 'Flock Performance KPIs', 'rows' => $rows];
    }

    if ($name === 'barren-cull-candidates') {
        // Find the most recent season that has any scan data at all.
        $latestSeason = null;
        foreach ($breeding as $b) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            if (!$animal || ($animal['species'] ?? null) !== 'sheep' || empty($b['scanResult'])) continue;
            $seasonDate = $b['expectedDate'] ?: ($b['actualDate'] ?: ($b['eventDate'] ?? null));
            if (!$seasonDate) continue;
            $year = substr($seasonDate, 0, 4);
            if ($latestSeason === null || $year > $latestSeason) $latestSeason = $year;
        }
        if (!$latestSeason) {
            return ['title' => 'Barren Ewes / Cull Candidates', 'rows' => []];
        }

        // Barren history per ewe across every season scanned, so a ewe
        // barren more than once (the strongest cull candidates) can be
        // flagged rather than just listing this season's empties flat.
        $historyByEwe = [];
        foreach ($breeding as $b) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            if (!$animal || ($animal['species'] ?? null) !== 'sheep' || empty($b['scanResult'])) continue;
            $aid = $b['animalId'];
            if (!isset($historyByEwe[$aid])) $historyByEwe[$aid] = ['scanned' => 0, 'barren' => 0];
            $historyByEwe[$aid]['scanned']++;
            if ($b['scanResult'] === 'empty') $historyByEwe[$aid]['barren']++;
        }

        $candidates = [];
        foreach ($breeding as $b) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            if (!$animal || ($animal['species'] ?? null) !== 'sheep') continue;
            if (in_array($animal['status'] ?? '', ['archived', 'deceased', 'sold'], true)) continue;
            if (($b['scanResult'] ?? '') !== 'empty') continue;
            $seasonDate = $b['expectedDate'] ?: ($b['actualDate'] ?: ($b['eventDate'] ?? null));
            if (!$seasonDate || substr($seasonDate, 0, 4) !== $latestSeason) continue;

            $hist = $historyByEwe[$b['animalId']] ?? ['scanned' => 1, 'barren' => 1];
            $candidates[] = ['animal' => $animal, 'scanDate' => $b['scanDate'] ?? '', 'barren' => $hist['barren'], 'scanned' => $hist['scanned']];
        }

        usort($candidates, function ($x, $y) { return $y['barren'] <=> $x['barren']; });

        $rows = [];
        foreach ($candidates as $c) {
            $a = $c['animal'];
            $rows[] = [
                'ewe' => $a['name'] ?: $a['tagNumber'],
                'tag' => $a['tagNumber'] ?? '',
                'breed' => $a['breed'] ?? '',
                'group' => $a['group'] ?? '',
                'scanDate' => $c['scanDate'],
                'barrenHistory' => $c['barren'] . ' of ' . $c['scanned'] . ' season(s) scanned',
                'repeatBarren' => $c['barren'] > 1 ? 'Yes' : 'No'
            ];
        }
        return ['title' => "Barren Ewes / Cull Candidates ({$latestSeason} season)", 'rows' => $rows];
    }

    if ($name === 'milk-production-summary') {
        return ['title' => 'Milk Production Summary', 'rows' => h_herd_daily_totals($milk)];
    }

    if ($name === 'butterfat-protein-summary') {
        $rows = [];
        foreach ($milktests as $mt) {
            $cow = h_find_by_id($animals, $mt['cowId'] ?? null);
            $rows[] = [
                'cow' => $cow ? ($cow['name'] ?: $cow['tagNumber']) : ($mt['cowId'] ?? ''),
                'date' => $mt['date'] ?? '', 'butterfat' => $mt['butterfat'] ?? '', 'protein' => $mt['protein'] ?? ''
            ];
        }
        return ['title' => 'Butterfat & Protein Summary', 'rows' => $rows];
    }

    if ($name === 'cell-count-report') {
        $rows = [];
        foreach ($milktests as $mt) {
            $cow = h_find_by_id($animals, $mt['cowId'] ?? null);
            $rows[] = [
                'cow' => $cow ? ($cow['name'] ?: $cow['tagNumber']) : ($mt['cowId'] ?? ''),
                'date' => $mt['date'] ?? '', 'scc' => $mt['scc'] ?? '',
                'flag' => (floatval($mt['scc'] ?? 0) > 200000) ? 'HIGH' : ''
            ];
        }
        return ['title' => 'Cell Count Report', 'rows' => $rows];
    }

    if ($name === 'calving-report') {
        $rows = [];
        foreach ($breeding as $b) {
            $animal = h_find_by_id($animals, $b['animalId'] ?? null);
            if (!$animal || !h_is_cattle($animal['species'] ?? null) || empty($b['actualDate'])) continue;
            $rows[] = [
                'cow' => $animal['name'] ?: $animal['tagNumber'],
                'type' => ($animal['species'] ?? null) === 'sucklercow' ? 'Suckler' : 'Dairy',
                'calvingDate' => $b['actualDate'],
                'bull' => $b['sireInfo'] ?? '', 'notes' => $b['notes'] ?? ''
            ];
        }
        return ['title' => 'Calving Report', 'rows' => $rows];
    }

    if ($name === 'herd-inventory') {
        $rows = [];
        foreach ($cattle as $a) {
            if (($a['status'] ?? null) === 'archived') continue;
            $rows[] = [
                'tag' => $a['tagNumber'] ?? '', 'name' => $a['name'] ?? '',
                'type' => ($a['species'] ?? null) === 'sucklercow' ? 'Suckler' : 'Dairy',
                'breed' => $a['breed'] ?? '', 'dob' => $a['dob'] ?? '', 'status' => $a['status'] ?? ''
            ];
        }
        return ['title' => 'Herd Inventory', 'rows' => $rows];
    }

    if ($name === 'movement-log') {
        $rows = [];
        foreach ($movements as $mv) {
            $animal = h_find_by_id($animals, $mv['animalId'] ?? null);
            $rows[] = [
                'animal' => $animal ? ($animal['name'] ?: $animal['tagNumber']) : ($mv['animalId'] ?? ''),
                'species' => $animal ? ($animal['species'] ?? '') : '',
                'date' => $mv['date'] ?? '',
                'direction' => (($mv['direction'] ?? '') === 'on') ? 'On' : 'Off',
                'reason' => $mv['reason'] ?? '',
                'location' => $mv['location'] ?? '',
                'reference' => $mv['locationReference'] ?? '',
                'price' => (isset($mv['price']) && $mv['price'] !== '') ? number_format((float) $mv['price'], 2) : '',
                'notes' => $mv['notes'] ?? ''
            ];
        }
        usort($rows, function ($a, $b) { return strtotime($b['date']) <=> strtotime($a['date']); });
        return ['title' => 'Movement Log', 'rows' => $rows];
    }

    if ($name === 'purchase-sale-summary') {
        $productStats = h_feed_product_stats($feedproducts, $feedpurchases, $feedusage);

        $byAnimal = [];
        foreach ($movements as $mv) {
            $reason = $mv['reason'] ?? '';
            if ($reason !== 'Purchase' && $reason !== 'Sale') continue;
            $aid = $mv['animalId'] ?? null;
            if (!$aid) continue;
            if (!isset($byAnimal[$aid])) {
                $byAnimal[$aid] = ['purchaseDate' => null, 'purchasePrice' => null, 'saleDate' => null, 'salePrice' => null];
            }
            $price = (isset($mv['price']) && $mv['price'] !== '') ? (float) $mv['price'] : null;
            if ($reason === 'Purchase') {
                $byAnimal[$aid]['purchaseDate'] = $mv['date'] ?? null;
                $byAnimal[$aid]['purchasePrice'] = $price;
            } else {
                $byAnimal[$aid]['saleDate'] = $mv['date'] ?? null;
                $byAnimal[$aid]['salePrice'] = $price;
            }
        }
        // Also include any animal with directly-attributed feed usage but
        // no purchase/sale movement recorded, so its feed spend still shows.
        foreach ($feedusage as $u) {
            $aid = $u['animalId'] ?? null;
            if ($aid && !isset($byAnimal[$aid])) {
                $byAnimal[$aid] = ['purchaseDate' => null, 'purchasePrice' => null, 'saleDate' => null, 'salePrice' => null];
            }
        }

        $rows = [];
        $totalPurchase = 0.0;
        $totalSale = 0.0;
        $totalFeed = 0.0;
        foreach ($byAnimal as $aid => $info) {
            $animal = h_find_by_id($animals, $aid);
            $feedResult = h_animal_feed_cost($aid, $feedusage, $productStats);
            $feedCost = $feedResult['total'];

            $profit = ($info['purchasePrice'] !== null && $info['salePrice'] !== null)
                ? round($info['salePrice'] - $info['purchasePrice'] - $feedCost, 2) : null;
            if ($info['purchasePrice'] !== null) $totalPurchase += $info['purchasePrice'];
            if ($info['salePrice'] !== null) $totalSale += $info['salePrice'];
            $totalFeed += $feedCost;
            $rows[] = [
                'animal' => $animal ? ($animal['name'] ?: $animal['tagNumber']) : $aid,
                'purchaseDate' => $info['purchaseDate'] ?? '',
                'purchasePrice' => $info['purchasePrice'] !== null ? number_format($info['purchasePrice'], 2) : '',
                'feedCost' => $feedCost > 0 ? number_format($feedCost, 2) : '',
                'saleDate' => $info['saleDate'] ?? '',
                'salePrice' => $info['salePrice'] !== null ? number_format($info['salePrice'], 2) : '',
                'profitLossAfterFeed' => $profit !== null ? number_format($profit, 2) : ''
            ];
        }

        usort($rows, function ($a, $b) { return strtotime($b['purchaseDate'] ?: $b['saleDate'] ?: '1970-01-01') <=> strtotime($a['purchaseDate'] ?: $a['saleDate'] ?: '1970-01-01'); });

        if (!empty($rows)) {
            $rows[] = [
                'animal' => 'TOTAL',
                'purchaseDate' => '',
                'purchasePrice' => number_format($totalPurchase, 2),
                'feedCost' => number_format($totalFeed, 2),
                'saleDate' => '',
                'salePrice' => number_format($totalSale, 2),
                'profitLossAfterFeed' => number_format($totalSale - $totalPurchase - $totalFeed, 2)
            ];
        }

        return ['title' => 'Purchase & Sale Summary', 'rows' => $rows];
    }

    if ($name === 'feed-cost-summary') {
        $productStats = h_feed_product_stats($feedproducts, $feedpurchases, $feedusage);
        $rows = [];
        $totalPurchased = 0.0;
        $totalUsedCost = 0.0;
        foreach ($productStats as $s) {
            $totalPurchased += $s['purchasedCost'];
            $totalUsedCost += $s['usedCost'];
            $rows[] = [
                'product' => $s['name'],
                'unit' => $s['unit'],
                'purchasedQty' => $s['purchasedQty'],
                'purchasedCost' => number_format($s['purchasedCost'], 2),
                'usedQty' => $s['usedQty'],
                'usedCost' => number_format($s['usedCost'], 2),
                'currentStock' => $s['currentStock'],
                'avgUnitCost' => number_format($s['avgUnitCost'], 2)
            ];
        }
        if (!empty($rows)) {
            $rows[] = [
                'product' => 'TOTAL', 'unit' => '', 'purchasedQty' => '',
                'purchasedCost' => number_format($totalPurchased, 2),
                'usedQty' => '', 'usedCost' => number_format($totalUsedCost, 2),
                'currentStock' => '', 'avgUnitCost' => ''
            ];
        }
        return ['title' => 'Feed Cost Summary', 'rows' => $rows];
    }

    return null;
}

// ---------- feed inventory & cost ----------

// Weighted-average cost per unit for every feed product, plus running
// stock (purchased minus used). Using an average across all purchases
// (rather than tracking individual batches/FIFO) keeps this simple and
// is standard practice for a farm this size.
function h_feed_product_stats($products, $purchases, $usage) {
    $stats = [];
    foreach ($products as $p) {
        $pid = $p['id'] ?? null;
        if (!$pid) continue;

        $purchasedQty = 0.0;
        $purchasedCost = 0.0;
        foreach ($purchases as $pu) {
            if (($pu['productId'] ?? null) !== $pid) continue;
            $purchasedQty += floatval($pu['quantity'] ?? 0);
            $purchasedCost += floatval($pu['totalCost'] ?? 0);
        }

        $usedQty = 0.0;
        foreach ($usage as $u) {
            if (($u['productId'] ?? null) !== $pid) continue;
            $usedQty += floatval($u['quantity'] ?? 0);
        }

        $avgUnitCost = $purchasedQty > 0 ? ($purchasedCost / $purchasedQty) : 0.0;

        $stats[$pid] = [
            'id' => $pid,
            'name' => $p['name'] ?? '',
            'unit' => $p['unit'] ?? '',
            'purchasedQty' => round($purchasedQty, 2),
            'purchasedCost' => round($purchasedCost, 2),
            'usedQty' => round($usedQty, 2),
            'usedCost' => round($usedQty * $avgUnitCost, 2),
            'currentStock' => round($purchasedQty - $usedQty, 2),
            'avgUnitCost' => round($avgUnitCost, 4)
        ];
    }
    return $stats;
}

// Feed cost directly attributable to one animal: only usage entries
// explicitly logged against that animal (e.g. calf milk replacer fed to
// one calf), valued at the product's weighted-average cost per unit.
// General/group feeding entries (no animalId set) are intentionally
// excluded here — dividing shared feed evenly across a group is rarely
// an accurate reflection of what any one animal actually ate, so those
// stay visible at the farm/group level (Feed Cost Summary) rather than
// being forced into a per-head figure.
function h_animal_feed_cost($animalId, $usage, $productStatsById) {
    $total = 0.0;
    $entries = [];
    foreach ($usage as $u) {
        if (($u['animalId'] ?? null) !== $animalId) continue;
        $pid = $u['productId'] ?? null;
        $product = $productStatsById[$pid] ?? null;
        $unitCost = $product ? $product['avgUnitCost'] : 0.0;
        $qty = floatval($u['quantity'] ?? 0);
        $cost = round($qty * $unitCost, 2);
        $total += $cost;
        $entries[] = [
            'date' => $u['date'] ?? '',
            'product' => $product ? $product['name'] : ($pid ?? 'Unknown product'),
            'unit' => $product ? $product['unit'] : '',
            'quantity' => $qty,
            'cost' => $cost
        ];
    }
    usort($entries, function ($a, $b) { return strtotime($b['date']) <=> strtotime($a['date']); });
    return ['total' => round($total, 2), 'entries' => $entries];
}

// ---------- CSV ----------

function h_to_csv($items) {
    if (empty($items)) return '';
    $keys = [];
    $seen = [];
    foreach ($items as $item) {
        foreach (array_keys($item) as $k) {
            if (!isset($seen[$k])) { $seen[$k] = true; $keys[] = $k; }
        }
    }
    $escape = function ($v) {
        if ($v === null) return '';
        $s = (string) $v;
        if (preg_match('/[",\n]/', $s)) return '"' . str_replace('"', '""', $s) . '"';
        return $s;
    };
    $lines = [implode(',', array_map($escape, $keys))];
    foreach ($items as $item) {
        $row = [];
        foreach ($keys as $k) $row[] = $escape($item[$k] ?? null);
        $lines[] = implode(',', $row);
    }
    return implode("\n", $lines);
}
