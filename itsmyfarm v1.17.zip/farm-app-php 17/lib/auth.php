<?php
// lib/auth.php — single-user login on top of PHP's built-in session
// handling and password_hash()/password_verify() (bcrypt under the hood).
// No external libraries. auth.json, the session store, and the lockout
// file are all kept outside data/animals.json etc. so a JSON backup
// restore can never touch your login.

if (!defined('FARM_APP')) { http_response_code(403); exit('Forbidden'); }

require_once __DIR__ . '/db.php';

define('SESSION_COOKIE_NAME', 'farm_session');
define('SESSION_LIFETIME', 60 * 60 * 24 * 30); // 30 days

function auth_file() {
    return db_data_dir() . '/auth.json';
}

function auth_lockout_file() {
    return db_data_dir() . '/lockout.json';
}

function auth_session_dir() {
    return db_data_dir() . '/sessions';
}

// ---------- account ----------

function auth_is_setup_complete() {
    return file_exists(auth_file());
}

function auth_create_account($username, $password) {
    if (auth_is_setup_complete()) throw new Exception('Setup has already been completed.');
    $username = trim((string) $username);
    if ($username === '') throw new Exception('Username is required.');
    if (!$password || strlen($password) < 8) throw new Exception('Password must be at least 8 characters.');
    $account = [
        'username' => $username,
        'hash' => password_hash($password, PASSWORD_DEFAULT),
        'createdAt' => date('c')
    ];
    db_write_raw(auth_file(), $account);
}

function auth_get_account() {
    if (!auth_is_setup_complete()) return null;
    return db_read_raw(auth_file(), null);
}

function auth_verify_password($password) {
    $account = auth_get_account();
    if (!$account || !isset($account['hash'])) return false;
    return password_verify((string) $password, $account['hash']);
}

function auth_verify_credentials($username, $password) {
    $account = auth_get_account();
    if (!$account) return false;
    if (!hash_equals((string) $account['username'], (string) $username)) return false;
    return auth_verify_password($password);
}

function auth_update_account($newUsername, $newPassword) {
    $account = auth_get_account();
    if (!$account) throw new Exception('Account is not set up yet.');
    if ($newUsername !== null && trim((string) $newUsername) !== '') {
        $account['username'] = trim((string) $newUsername);
    }
    if ($newPassword) {
        if (strlen($newPassword) < 8) throw new Exception('New password must be at least 8 characters.');
        $account['hash'] = password_hash($newPassword, PASSWORD_DEFAULT);
    }
    $account['updatedAt'] = date('c');
    db_write_raw(auth_file(), $account);
    return $account['username'];
}

// ---------- sessions (PHP native $_SESSION, stored in our own data
// directory rather than the shared system tmp dir some hosts use) ----------

function auth_is_https() {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') return true;
    return false;
}

function auth_start_session() {
    if (session_status() === PHP_SESSION_ACTIVE) return;

    $sessionDir = auth_session_dir();
    if (!is_dir($sessionDir)) @mkdir($sessionDir, 0700, true);
    if (is_dir($sessionDir) && is_writable($sessionDir)) {
        session_save_path($sessionDir);
    }

    session_name(SESSION_COOKIE_NAME);
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => auth_is_https()
    ]);
    session_start();
}

function auth_login_session() {
    session_regenerate_id(true);
    $_SESSION['authenticated'] = true;
    $_SESSION['loginAt'] = time();
}

function auth_is_authenticated() {
    return !empty($_SESSION['authenticated']);
}

function auth_logout() {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    session_destroy();
}

// ---------- brute-force lockout ----------
// PHP has no long-lived process to hold this in memory between requests
// (unlike the Node version), so it lives in a small JSON file instead.

define('LOCKOUT_MAX_ATTEMPTS', 6);
define('LOCKOUT_SECONDS', 5 * 60);

function auth_is_locked($key) {
    $data = db_read_raw(auth_lockout_file(), []);
    if (!isset($data[$key])) return false;
    $entry = $data[$key];
    if (!empty($entry['lockedUntil']) && $entry['lockedUntil'] > time()) return true;
    return false;
}

function auth_record_failure($key) {
    $data = db_read_raw(auth_lockout_file(), []);
    if (!isset($data[$key])) $data[$key] = ['count' => 0];
    $data[$key]['count'] = ($data[$key]['count'] ?? 0) + 1;
    if ($data[$key]['count'] >= LOCKOUT_MAX_ATTEMPTS) {
        $data[$key]['lockedUntil'] = time() + LOCKOUT_SECONDS;
    }
    // opportunistic cleanup so this file doesn't grow forever
    $now = time();
    foreach ($data as $k => $entry) {
        $stale = empty($entry['lockedUntil']) ? false : $entry['lockedUntil'] < ($now - 3600);
        if ($stale) unset($data[$k]);
    }
    db_write_raw(auth_lockout_file(), $data);
}

function auth_record_success($key) {
    $data = db_read_raw(auth_lockout_file(), []);
    if (isset($data[$key])) {
        unset($data[$key]);
        db_write_raw(auth_lockout_file(), $data);
    }
}
