<?php
// lib/path.php — detects the URL path this app is deployed under, so it
// works correctly whether it's installed at the root of a domain/
// subdomain (https://example.com/) or in a subfolder
// (https://example.com/farm/). Computed from SCRIPT_NAME, which the web
// server always sets to the current script's path relative to the web
// root (e.g. "/farm/index.php" or "/index.php") — no manual
// configuration needed.

if (!defined('FARM_APP')) { http_response_code(403); exit('Forbidden'); }

function app_base_path() {
    static $base = null;
    if ($base !== null) return $base;
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $dir = str_replace('\\', '/', dirname($script));
    $base = ($dir === '/' || $dir === '.' || $dir === '') ? '' : rtrim($dir, '/');
    return $base;
}
